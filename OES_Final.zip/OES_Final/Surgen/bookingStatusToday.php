<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<?php
session_start();
include("header.php"); 
include 'dbconn.php';
require_once("../ConnectionClass.php");
$obj= new ConnectionClass();
$username=$_SESSION['username'];
echo $sql1="select s_id from surgen where email='$username'";
echo $c1=$obj->GetSingleData($sql1);
//$id =$_SESSION["id"];

?>

<body>
<center>
 <p>&nbsp;</p>
  <div class="services-heading">
				<h2>Today's Appointment</h2>
  </div>

<p>&nbsp;</p>
<p>&nbsp;</p>

<table width="894" height="84" >
  <tr>
    <td width="88" height="31"><div align="center"><strong>Booking Id </strong></div></td>
    <td width="232"><div align="center"><strong>Patient Name </strong></div></td>
    <td width="182"><div align="center"><strong>Date</strong></div></td>
    <td width="150"><div align="center"><strong>Edit</strong></div></td>
  </tr>
  <?php 
    $nowd= date('Y-m-d');
  	$sql="select * from surgenappointment where s_id=$c1 and bdate='$nowd' and status='Approved'"; //echo $sql;
	$result=@mysqli_query($con,$sql);
 	while($row=@mysqli_fetch_array($result))
	{
			//$branch =  $row['branch_id'];
	 	 	//$s="select * from branch where branch_id=$branch";
			//$r=@mysqli_query($con,$s); 
			//$rw=@mysqli_fetch_array($r);//echo $s;
			//$branch_name = $rw["branch_name"];
			
			$pat_id =  $row['pat_id'];
	 	 	$s="select * from patient where pat_id=$pat_id";
			$r=@mysqli_query($con,$s); 
			$rw=@mysqli_fetch_array($r);//echo $s;
			$name = $rw["pat_name"];

  ?>
  <tr>
    <td><div align="center"><?php echo $row['sapp_id']; ?>&nbsp;</div></td>
    <td><div align="center"><?php echo $name; ?>&nbsp;</div></td>
	<td><div align="center"><?php echo $row['bdate']; ?>&nbsp;</div></td>
	<td><div align="center"> <a href="patientDetails.php?id=<?php echo $pat_id; ?>&sapp_id=<?php echo $row['sapp_id']; ?>"><i class=" fa fa-hospital-o" aria-hidden="true"></i></a>&nbsp;</div></td>
  </tr>
  <?php } ?>
</table>
</center>
	
	<!-- footer -->
	<div class="w3-agile-footer">
		<div class="container">
			
			<div class="agileits-w3layouts-copyright">
				<p>� 2018 Online eye care . All Rights Reserved | Design by <a href="https://www.facebook.com/sreekutty.prakash.9"> SSSP</a> </p>
			</div>
		</div>
	</div>
	<!-- //footer -->
</body>
</html>
