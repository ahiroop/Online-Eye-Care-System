<?php 
session_start(); 

//echo $id= $_SESSION["id"]; // echo $userId;
include 'dbconn.php';
echo $sapp_id=$_REQUEST['sapp_id'];
echo $sql="update surgenappointment set status='Approved' where sapp_id=$sapp_id";
		mysqli_query($con,$sql) or die();
		header("location:viewBooking.php");
?>