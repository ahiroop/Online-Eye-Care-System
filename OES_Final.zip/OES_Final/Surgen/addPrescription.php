<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

</head>
<?php 
session_start();
//$id =$_SESSION["id"];
include("header.php"); ?>
<?php
include 'dbconn.php';
$pat_id= $_REQUEST['pat_id'];
//$sapp_id= $_REQUEST['sapp_id'];
require_once("../ConnectionClass.php");
$obj= new ConnectionClass();
$username=$_SESSION['username'];
echo $sql="select sapp_id from surgenappointment where pat_id='$pat_id'";
echo $c2=$obj->GetSingleData($sql);

echo $sql1="select s_id from surgen where email='$username'";
echo $c1=$obj->GetSingleData($sql1);

$sql="select * from patient where pat_id=$pat_id";// echo $sql;
		$result=@mysqli_query($con,$sql);
		$row=@mysqli_fetch_array($result);
echo $pat_name = $row['pat_name'];

if($_SERVER["REQUEST_METHOD"] == "POST")	
{
	
	$medicine=$_POST['medicine'];
	$dosage=$_POST['dosage'];
	$noofDays=$_POST['noofDays'];
	$msg=$_POST['msg'];
	$date= date('Y-m-d');
	
	echo$sql="insert into surgenprescription(medicines,noofDays,dosage,pat_id,s_id,msg,mdate) values('$medicine','$noofDays','$dosage','$pat_id','$c1','$msg','$date')";
		//echo $sql;
		@mysqli_query($con,$sql) or die();
		
		echo'<script type="text/javascript"> alert("Added...!");</script>';
	
}
	?>
<body>

<center>
 <p>&nbsp;</p>
  <div class="services-heading">
				<h2>Add Prescription</h2>
  </div>

<p>&nbsp;</p>
<p><a href="patientDetails.php?id=<?php echo $pat_id; ?>$c2=<?php echo $c2; ?>"><i class=" fa  fa-arrow-left" aria-hidden="true"></i>Back</a></p>
<p>&nbsp;</p>

<form  name="form1" method="post" >
  <table width="656" height="401">
    <tr>
      <th width="231" scope="row"> Name</th>
      <td width="153"><label>
        <input type="text" name="pat_name" value="<?php echo $pat_name; ?>" readonly="" />
      </label></td>
    </tr>
    <tr>
      <th scope="row">Medicine Name</th>
      <td><label>
      <input type="text" name="medicine"  required />
      </label></td>
    </tr>
   	<tr>
      <th scope="row">Dosage</th>
      <td><label>
      <input type="text" name="dosage"  required />
      </label></td>
    </tr>
	<tr>
      <th scope="row">No of Days</th>
      <td><label>
      <input type="text" name="noofDays"  required />
      </label></td>
    </tr>
    <tr>
      <th scope="row">Message</th>
      <td><label>
      <input type="text" name="msg"  required />
      </label></td>
    </tr>
	
  </table>
  <p>
    <label>
    <input type="submit" name="Submit" value="Add Prescription" />
    </label>
  </p>
</form>
<p>&nbsp;</p>
</center>
	
	<!-- footer -->
	<div class="w3-agile-footer">
		<div class="container">
			
			<div class="agileits-w3layouts-copyright">
				<p>� 2018 Online eye care . All Rights Reserved | Design by <a href="https://www.facebook.com/sreekutty.prakash.9"> SSSP</a> </p>
			</div>
		</div>
	</div>
	<!-- //footer -->
</body>
</html>
