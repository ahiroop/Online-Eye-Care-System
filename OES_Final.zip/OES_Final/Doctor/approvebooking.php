<?php 
session_start(); 

$id= $_SESSION["id"]; // echo $userId;
include 'dbconn.php';
$app_id=$_REQUEST['app_id'];
$sql="update appointment set status='Approved' where app_id=$app_id";
		mysqli_query($con,$sql) or die();
		header("location:viewBooking.php");
?>