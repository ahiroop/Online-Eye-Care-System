<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

</head>
<?php
session_start();
//session_start();
include("header.php"); 
include 'dbconn.php';
?>
<body>

<center>
 <p>&nbsp;</p>
  <div class="services-heading">
				<h2>View Surgen</h2>
  </div>

<p>&nbsp;</p>
<p>&nbsp;</p>

  <div class="bs-docs-example wow fadeInUp animated" data-wow-delay=".5s">
  <table width="420" height="104" class="table">
  <thead>
    <tr>
      <th ><strong>Sl. No. </strong></th>
      <th><strong>Name</strong></th>
	  <th><strong>Category</strong></th>
     <th><strong>Email</strong></th>
      <th><strong>Contact No.</strong></th>
      
    </tr>
	</thead>
	<tbody>
	<?php
			$sql1="SELECT * FROM (SELECT * FROM surgen ORDER BY s_id DESC LIMIT 5) sub ORDER BY s_id ASC;";
			$result=mysqli_query($con,$sql1);
			$s =0;
			while($row=mysqli_fetch_array($result))
			{
			$s=$s+1;
	?>
	
    <tr>
      <td><?php echo $s; ?>&nbsp;</td>
      <td><?php echo $row['name']; ?>&nbsp;</td>
	  <td><?php echo $row['category']; ?>&nbsp;</td>
      <td><?php echo $row['email']; ?>&nbsp;</td>
      <td><?php echo $row['phone']; ?>&nbsp;</td>
     
    </tr>
	
	<?php  } ?>
	</tbody>
  </table>
</div>
<p>&nbsp;</p>
</center>
	<!-- footer -->
	<div class="w3-agile-footer">
		<div class="container">
			
			<div class="agileits-w3layouts-copyright">
				<p>� 2018 Online eye care . All Rights Reserved | Design by <a href="https://www.facebook.com/sreekutty.prakash.9"> SSSP</a> </p>
			</div>
		</div>
	</div>
	<!-- //footer -->
</body>
</html>
