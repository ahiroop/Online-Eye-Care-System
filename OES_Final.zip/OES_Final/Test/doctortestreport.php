<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script>
function date()

let today = new Date().toLocaleDateString()

console.log(today)

</script>
</head>
<?php 
session_start();
//$id =$_SESSION["id"];
include("header.php"); 
?>
<?php
include 'dbconn.php';
$pat_id= $_REQUEST['pat_id'];
//$sapp_id= $_REQUEST['sapp_id'];
require_once("../ConnectionClass.php");
$obj= new ConnectionClass();
echo $sql1="select test from test where pat_id='$pat_id'";
echo $c2=$obj->GetSingleData($sql1);
echo $sql="select test_id from test where pat_id='$pat_id'";
echo $t=$obj->GetSingleData($sql);
echo $sql2="select doc_id from test where pat_id='$pat_id'";
echo $c3=$obj->GetSingleData($sql2);
$sql="select * from patient where pat_id=$pat_id";// echo $sql;
		$result=@mysqli_query($con,$sql);
		$row=@mysqli_fetch_array($result);
echo $pat_name = $row['pat_name'];
echo $doc_name = $row['doctor_name'];
if($_SERVER["REQUEST_METHOD"] == "POST")	
{
	echo $pat_name = $row['pat_name'];
	//echo $doc_name = $_GET['doctor_name'];
	echo $report=$_POST['report'];
	//echo $date=date();
	
	echo$sql="insert into doctortestreport(pat_name,tname,report,pat_id,doctor_id,test_id) values('$pat_name','$c2','$report','$pat_id','$c3','$t')";
		//echo $sql;
		@mysqli_query($con,$sql) or die();
		
		echo'<script type="text/javascript"> alert("Added...!");</script>';
	
}



?>
<body>

<center>
 <p>&nbsp;</p>
  <div class="services-heading">
				<h2>Generate report</h2>
  </div>

<p>&nbsp;</p>
<p><a href="viewdoctortest.php?id=<?php echo $pat_id; ?>$c3=<?php echo $c3; ?>"><i class=" fa  fa-arrow-left" aria-hidden="true"></i>Back</a></p>
<p>&nbsp;</p>

<form  name="form1" method="post" >
  <table width="656" height="401">
    <tr>
      <th width="231" scope="row">Patient Name&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;:</th>
      <td width="153"><label><?php echo $pat_name; ?>
      </label></td>
    </tr>
	<!--<tr>
      <th width="231" scope="row">Doctor Name&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;:</th>
      <td width="153"><label></?php echo $doc_name; ?>
      </label></td>
    </tr>-->
    <tr>
      <th scope="row">Test Name&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</th>
      <td><label><?php echo $c2;?>
      </label></td>
    </tr>
	<!--<tr>
      <th scope="row">Test Date:</th>
      <td><label></?php echo Date(); ?>
      
      </label></td>
    </tr>-->
   	<tr>
      <th scope="row">Report&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;:</th>
      <td>
      <textarea type="text" name="report"  required /></textarea>
      </td>
    </tr>
	
  </table>
  <p>
    <label>
    <input type="submit" name="Submit" value="Submit" />
    </label>
  </p>
</form>
<p>&nbsp;</p>
</center>
	
	<!-- footer -->
	<div class="w3-agile-footer">
		<div class="container">
			
			<div class="agileits-w3layouts-copyright">
				<p>� 2018 Online eye care . All Rights Reserved | Design by <a href="https://www.facebook.com/sreekutty.prakash.9"> SSSP</a> </p>
			</div>
		</div>
	</div>
	<!-- //footer -->
</body>
</html>
