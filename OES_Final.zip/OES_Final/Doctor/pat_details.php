<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

</head>
<?php
session_start();
include("header.php"); 
include 'dbconn.php';
//$id =$_SESSION["id"];
$pat_id= $_REQUEST['pat_id'];

$sql="select * from patient where pat_id=$pat_id";// echo $sql;
		$result=mysqli_query($con,$sql);
		$row=@mysqli_fetch_array($result);
// vie w medicine details

	
?>
<body>

<center>
  <p>&nbsp;</p>
  <div class="services-heading">
				<h2>Patient Details</h2>
  </div>

<p>&nbsp;</p>
<form  name="form1" method="post" >
  <table width="699" height="262">
    <tr>
      <th width="344" scope="row"><div align="center">Name</div></th>
      <td width="343"><label>
        <?php echo $row["pat_name"]; ?>
      </label></td>
    </tr>
    <tr>
      <th scope="row"><div align="center">Address </div></th>
      <td><label>
      <?php echo $row["address"]; ?>
      </label></td>
    </tr>
   <tr>
      <th scope="row"><div align="center">Gender </div></th>
      <td><label>
      <?php echo $row["gender"]; ?>
      </label></td>
    </tr>
	<tr>
      <th scope="row"><div align="center">DOB </div></th>
      <td><label>
      <?php echo $row["dob"]; ?>
      </label></td>
    </tr>
    <tr>
      <th scope="row"><div align="center">Email Id </div></th>
      <td><label>
      <?php echo $row["email_id"]; ?>
      </label></td>
    </tr>
    <tr>
      <th scope="row"><div align="center">Contact No.</div></th>
      <td><label>
      <?php echo $row["contact"]; ?>
      </label></td>
    </tr>
  </table>
   <p>&nbsp;</p>
   <div >
  <p><a href="viewPatients.php"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</a></p>
  </div>
   <p><a href="viewPrescription.php?pat_id=<?php echo $row["pat_id"]; ?>">View Prescription</a>  ||  <a href="viewTestdetails.php?pat_id=<?php echo $row["pat_id"]; ?>">View Test Details</a>  </p>
   <p>&nbsp;</p>
</form>
<p>&nbsp;</p>
</center>
	
	<!-- footer -->
	<div class="w3-agile-footer">
		<div class="container">
			
			<div class="agileits-w3layouts-copyright">
				<p>� 2018 Online eye care . All Rights Reserved | Design by <a href="https://www.facebook.com/sreekutty.prakash.9"> SSSP</a> </p>
			</div>
		</div>
	</div>
	<!-- //footer -->
</body>
</html>
