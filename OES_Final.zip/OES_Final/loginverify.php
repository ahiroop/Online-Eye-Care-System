<?php
session_start();
var_dump($_POST); 
$username= $_POST['username'];
$password= $_POST['password'];
//echo $username.$pwd;
require_once("ConnectionClass.php");
$obj=new ConnectionClass();
echo $queryu="select utype from login where username='$username' and password='$password' and status='active'";
echo $utype=$obj->GetSingleData($queryu);
//echo $utype;
$_SESSION['utype']=$utype;
if ($utype=="admin") {
	$_SESSION['utype']=$utype;
	$_SESSION['username']=$username;
	$_SESSION['password']=$password;
	header("Location:Admin/home.php");
}
else if($utype=="patient"){
	
	    echo $_SESSION['utype']=$utype;
		echo $_SESSION['username']=$username;
	   echo  $_SESSION['password']=$password;
	header("Location:Patient/home.php");
}

else if($utype=="doctor"){
	$_SESSION['utype']=$utype;
		$_SESSION['username']=$username;
	    $_SESSION['password']=$password;
	header("Location:Doctor/home.php");
}
else if($utype=="surgen"){
	$_SESSION['utype']=$utype;
		$_SESSION['username']=$username;
	    $_SESSION['password']=$password;
	header("Location:surgen/home.php");
}
else if($utype=="test"){
	$_SESSION['utype']=$utype;
		$_SESSION['username']=$username;
	    $_SESSION['password']=$password;
	header("Location:Test/home.php");
}
else if($utype=="shope"){
	$_SESSION['utype']=$utype;
		$_SESSION['username']=$username;
	    $_SESSION['password']=$password;
	header("Location:Shope/home.php");
}
else 
{
	$obj->alert("Try again","login.php");
}
?>