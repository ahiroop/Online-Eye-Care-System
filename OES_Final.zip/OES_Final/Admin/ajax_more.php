<?php
if(!empty($_POST["doctor_id"])){

    // Include the database configuration file
 require_once("ConnectionClass.php");
$obj=new ConnectionClass();
   include("header.php");
include('dbconn.php'); 
    // Count all records except already displayed
    echo $query = $db->query("SELECT COUNT(*) as num_rows FROM doctor WHERE doctor_id < ".$_POST['doctor_id']." ORDER BY doctor_id DESC");
    $row = $query->fetch_assoc();
    $totalRowCount = $row['num_rows'];
    
    $showLimit = 5;
    
    // Get records from the database
    $query = $db->query("SELECT * FROM doctor WHERE doctor_id < ".$_POST['doctor_id']." ORDER BY doctor_id DESC LIMIT $showLimit");

    if($query->num_rows > 0){ 
        while($row = $query->fetch_assoc()){
            $doc_id = $row['doctor_id'];
    ?>
       
    <?php } ?>
    <?php if($totalRowCount > $showLimit){ ?>
        <div class="show_more_main" id="show_more_main<?php echo $doc_id; ?>">
            <!--<span id="</?php echo $postID; ?>" class="show_more" title="Load more posts">Show more</span>
            <span class="loding" style="display: none;"><span class="loding_txt">Loading...</span></span>-->
        </div>
    <?php } ?>
<?php
    }
}
?>