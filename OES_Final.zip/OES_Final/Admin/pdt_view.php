<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
</head>
<?php
 session_start();
 include 'dbconn.php';
 include("header.php");
  ?>

<body>

 <p>&nbsp;</p>
  <div class="services-heading">
				<h2>Products</h2>
  </div>

<p>&nbsp;</p>
<p>&nbsp;</p>

<!--gallery-->
	<div class="gallery">
		<div class="container">
		
			<?php 
			$sql="select * from product";
			$result=mysqli_query($con,$sql);
			$s =0;
			while($row=mysqli_fetch_array($result))
			{ 
			
			
			?>
			<div class="agileinfo-gallery" >
				<div class="col-md-3 w3-agileits-gallery-grids wthree">
					<p><a class="w3 wow zoomIn animated" data-wow-delay=".5s" href="pdtDetails.php?pdt_id=<?php echo $row['pdt_id']; ?>" >
					  <img src="<?php echo $row['pic']; ?>" class="img-responsive zoom-img" alt=""/>
					  </a></p>
					<p>&nbsp;</p>
					<p align="center" ><?php echo $row['pdt_name']; ?></p>
					<p align="center"><?php echo $row['pdt_cost']; ?></p>
					
					<a class="w3 wow zoomIn animated" data-wow-delay=".5s" href="<?php echo $row['pic']; ?>"data-lightbox="example-set" data-title="<?php echo $row['pdt_name']; ?>">
					<div class="agile-b-wrapper">
						<h5><span><?php echo $row['pdt_cost']; ?></span></h5>
						<p>&nbsp;</p>
					</div>
					</a>				
					</div>
				</div>
				<?php } ?>				
				
				<p>&nbsp;</p>
				<div class="clearfix"> </div>
				<script src="js/lightbox-plus-jquery.min.js"> </script>
			</div>	
		</div>	
	</div>	
	<!--//gallery-->

	<!-- footer -->
	<div class="w3-agile-footer">
		<div class="container">
			
			<div class="agileits-w3layouts-copyright">
				<p>� 2018 Online eye care . All Rights Reserved | Design by <a href="https://www.facebook.com"> SSSP</a> </p>
			</div>
		</div>
	</div>
	<!-- //footer -->
</body>
</html>
