<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

</head>
<?php
session_start();
include("header.php"); 
include 'dbconn.php';
$id =$_SESSION["id"];
echo $sql="select * from admin where admin_id=$id";// echo $sql;
		$result=mysqli_query($con,$sql);
		$row=mysqli_fetch_array($result);

	?>
<body>
 

<center>
<p>&nbsp;</p>
  <div class="services-heading">
				<h2>View Profile</h2>
  </div>

<p>&nbsp;</p>
<div class="well">
<form  name="form1" method="post" >
  <table width="398" height="163">
    <tr>
      <th width="193" scope="row"><div align="left">Admin Name</div></th>
      <td width="193"><label>
        <div align="left"><?php echo $row["admin_name"]; ?>          </div>
      </label></td>
    </tr>
    <tr>
      <th width="193" scope="row"><div align="left">Branch Name</div></th>
      <td width="193"><label>
        <div align="left">
          <?php 
			$branch_id = $row['branch_id'];
		 	$ss="select * from branch where branch_id=$branch_id"; //echo $ss;
			$rr=mysqli_query($con,$ss);
			$rww=mysqli_fetch_array($rr);
			echo $rww["branch_name"];
		?>
          </div>
      </label></td>
    </tr>
   
    <tr>
      <th scope="row"><div align="left">Email Id </div></th>
      <td><label>
      <div align="left"><?php echo $row["email_id"]; ?>      </div>
      </label></td>
    </tr>
  </table>
 
</form>
</div>
<p>&nbsp;</p>
</center>
	<!-- footer -->
	<div class="w3-agile-footer">
		<div class="container">
			
			<div class="agileits-w3layouts-copyright">
				<p>� 2018 Online eye care . All Rights Reserved | Design by <a href="https://www.facebook.com/sreekutty.prakash.9"> SSSP</a> </p>
			</div>
		</div>
	</div>
	<!-- //footer -->
</body>
</html>
