<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
</head>
<?php
session_start();
require_once("../ConnectionClass.php");
$obj= new ConnectionClass();
include("header.php"); 
include 'dbconn.php';
$username=$_SESSION['username'];
//$id =$_SESSION["id"];
echo $sql1="select pat_id from patient where email_id='$username'";
echo $c1=$obj->GetSingleData($sql1);
$sql="select * from patient where pat_id=$c1";// echo $sql;
		$result=@mysqli_query($con,$sql);
		$row=@mysqli_fetch_array($result);

?>
<body>

<center>
 <p>&nbsp;</p>
  <div class="services-heading">
				<h2>View Profile</h2>
  </div>

<p>&nbsp;</p>

<p>&nbsp;</p>
<div class="well">
<form  name="form1" method="post" >
  <p>&nbsp;</p>
  <table width="550" height="262">
    <tr>
      <th width="325" scope="row"><div align="left">Name</div></th>
      <td width="317"><strong>
        <label>
        : <?php echo $row["pat_name"]; ?>        </label>
      </strong> </td>
    </tr>
    <tr>
      <th scope="row"><div align="left">Address </div></th>
      <td><strong>
        <label>: 
        <?php echo $row["address"]; ?>        </label>
      </strong> </td>
    </tr>
   <tr>
      <th scope="row"><div align="left">Gender </div></th>
      <td><strong>
        <label>: 
        <?php echo $row["gender"]; ?>        </label>
      </strong> </td>
    </tr>
	<tr>
      <th scope="row"><div align="left">DOB </div></th>
      <td><strong>
        <label>: 
        <?php echo $row["dob"]; ?>        </label>
      </strong> </td>
    </tr>
    <tr>
      <th scope="row"><div align="left">Email Id </div></th>
      <td><strong>
        <label>: 
        <?php echo $row["email_id"]; ?>        </label>
      </strong> </td>
    </tr>
    <tr>
      <th scope="row"><div align="left">Contact No.</div></th>
      <td><strong>
        <label>: 
        <?php echo $row["contact"]; ?>        </label>
      </strong> </td>
    </tr>
  </table>
 
  <p>&nbsp;</p>
</form>
</div>
<p>&nbsp;</p>
</center>
	
	<!-- footer -->
	<div class="w3-agile-footer">
		<div class="container">
			
			<div class="agileits-w3layouts-copyright">
				<p>� 2018 Online eye care . All Rights Reserved | Design by <a href="https://www.facebook.com/sreekutty.prakash.9"> SSSP</a> </p>
			</div>
		</div>
	</div>
	<!-- //footer -->
</body>
</html>
