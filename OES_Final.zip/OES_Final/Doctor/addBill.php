<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

</head>
<?php 
session_start();
//$id =$_SESSION["id"];
include("header.php"); ?>
<?php
include 'dbconn.php';
$pat_id= $_REQUEST['pat_id'];
$app_id= $_REQUEST['app_id'];

$sql="select * from patient where pat_id=$pat_id";// echo $sql;
		$result=mysqli_query($con,$sql);
		$row=mysqli_fetch_array($result);
		$pat_name = $row['pat_name'];
$billno= rand(1,10000000);

if($_SERVER["REQUEST_METHOD"] == "POST")	
{
	
	$date=date('Y-m-d');
	
	$sql="insert into bill(billno,pat_id,ddate,amount,doc_id) values ('$billno','$pat_id','$date','$amount','$id')";
		//echo $sql;
		mysqli_query($con,$sql) or die();
		
		echo '<script type="text/javascript"> alert("Added...!");</script>';
	
	$sql="update appointment set status='Visited' where app_id=$app_id";// echo $sql;
	mysqli_query($con,$sql) or die();
	header("location:bookingStatusToday.php");
}
	?>
<body>

<center>
 <p>&nbsp;</p>
  <div class="services-heading">
				<h2>Add Bill Details</h2>
  </div>

<p>&nbsp;</p>
<p><a href="patientDetails.php?id=<?php echo $pat_id; ?>&app_id=<?php echo $app_id; ?>"><i class=" fa  fa-arrow-left" aria-hidden="true"></i>Back</a></p>
<p>&nbsp;</p>

<form  name="form1" method="post" >
  <table width="656" height="401">
    <tr>
      <th width="231" scope="row">Name </th>
      <td width="153"><label>
        <input type="text" name="pat_name" value="<?php echo $pat_name; ?>" readonly="" />
      </label></td>
    </tr>
    <tr>
      <th scope="row">Bill No. </th>
      <td><label>
      <input type="text" name="billno" value="<?php echo $billno; ?>"  required readonly="" />
      </label></td>
    </tr>
   	<tr>
      <th scope="row">Date</th>
      <td><label>
      <input type="text" name="date" value="<?php echo $date; ?>"  required readonly="" />
      </label></td>
    </tr>
	<tr>
      <th scope="row">Amount</th>
      <td><label>
      <input type="text" name="amount"  required />
      </label></td>
    </tr>
    
  </table>
  <p>
    <label>
    <input type="submit" name="Submit" value="Add Bill" />
    </label>
  </p>
</form>
<p>&nbsp;</p>
</center>
	
	<!-- footer -->
	<div class="w3-agile-footer">
		<div class="container">
			
			<div class="agileits-w3layouts-copyright">
				<p>� 2018 Online eye care . All Rights Reserved | Design by <a href="https://www.facebook.com/sreekutty.prakash.9"> SSSP</a> </p>
			</div>
		</div>
	</div>
	<!-- //footer -->
</body>
</html>
