<!DOCTYPE html>
<html lang="en">
<head>

</head>
<?php 
session_start();
include("header.php"); 
include 'dbconn.php';
require_once("../ConnectionClass.php");
$username=$_SESSION['username'];
$obj=new ConnectionClass();
echo $sql1="select pat_id from patient where email_id='$username'";
echo $c1=$obj->GetSingleData($sql1);
$s_id= $_REQUEST['s_id'];
echo $sql1="select category from surgen where s_id='$s_id'";
echo $c2=$obj->GetSingleData($sql1);


//dotor deatils

	$sql="select * from surgen where s_id=$s_id"; //echo $sql;
		
	$result=mysqli_query($con,$sql);
	$records=mysqli_num_rows($result);
	$row=mysqli_fetch_array($result);
	//$branch_id= $row['branch_id'];
	
if($_SERVER["REQUEST_METHOD"] == "POST")	
{
	$name=$_POST['name'];
	$bdate=$_POST['bdate'];
	//$time=$_POST['time']; //echo $btime;
	
	//booking date checking
	$book= date('Y-m-d');
	//dob Validation
	if($bdate <= $book)
		{
			$dateErr="Select a Valid date (eg : from tomorrow)";
			$status="true";
		}
		
		// checking avaliable tym of doctor
	//$sql="select * from appointment where bdate='$bdate' and doctor_id='$doctor_id'"; //echo $sql;
	//$result=mysqli_query($con,$sql);
	//$records=mysqli_num_rows($result);
	//if($records > 0) {
			//$tymErr="Time slote not available..!";
			//$status="true";
	//}//
		// checking avaliable tym of patient
	echo $sql="select * from surgenappointment where bdate='$bdate' and pat_id='$c1'"; //echo $sql;
	$result=@mysqli_query($con,$sql);
	$records=@mysqli_num_rows($result);
	if($records > 0) {
			echo '<script type="text/javascript"> alert("already booked");window.Location=\'bookSurgen.php\';</script>';
			$status="true";
	}
	//<!--if($time == "-Select Time-") 
	//{//
	//$status="true";
	//$tymErr="Select Time...";
	//}//
	if(!isset($status))
	{

		echo $sql="insert into surgenappointment(pat_id,s_id,category,bdate,status) values ('$c1','$s_id','$c2','$bdate','Pending')";
		//echo $sql;
		mysqli_query($con,$sql) or die();
			echo '<script type="text/javascript"> alert("Successfull");window.Location=\'login.php\';</script>';
	
	}
}
?>
<body>
<center>
 <p>&nbsp;</p>
  <div class="services-heading">
				<h2> Apponitment</h2>
  </div>

<p>&nbsp;</p>
<p>&nbsp;</p>
<form action="" method="post">

<table width="958" height="239">
  <tr>
    <td width="208">Doctor Name </td>
    <td width="264"><label>
      <input type="text" name="name" value="<?php echo "Dr. " ?><?php echo $row['name']; ?>" readonly="" />
    </label></td>
  </tr>
  <tr>
    <td width="208">Category</td>
    <td width="264"><label>
      <input type="text" name="cat" value="<?php echo $row['category']; ?>" readonly="" />
    </label></td>
  </tr>
  <!--<tr>
    <td>Branch </td>
    <td><label>
	 <input type="hidden" name="branch_id" value="</?php echo $branch_id; ?>" readonly=""  />
	</?php
	// branch form branch id
			$branch_id = $row['branch_id'];
		 	$ss="select * from branch where branch_id=$branch_id"; //echo $ss;
			$rr=mysqli_query($con,$ss);
			$rww=mysqli_fetch_array($rr);
			 $branch =$rww["branch_name"];
	 ?>
	
    <input type="text" name="branch" value="</?php echo $branch; ?>" readonly=""  />
    </label></td>
  </tr>-->
 
    <td>Date</td>
    <td><label>
    <input type="date" name="bdate"  value="<?php if(isset($bdate)) echo $bdate; ?>" required/>
    </label></td>
	 <td width="470"> <span style="color:#FF0000;"><?php if(isset($dateErr)) echo $dateErr; ?></span></td>
  </tr>
</table>
<p>&nbsp;</p>
<p>
  <label>
  <input type="submit" name="Submit" value="Procced Booking" />
  </label>
</p>
<p>&nbsp;</p>
</form>
</center>
	
	<!-- footer -->
	<div class="w3-agile-footer">
		<div class="container">
			
			<div class="agileits-w3layouts-copyright">
				<p>� 2018 Online eye care . All Rights Reserved | Design by <a href="https://www.facebook.com/sreekutty.prakash.9"> SSSP</a> </p>
			</div>
		</div>
	</div>
	<!-- //footer -->
</body>
</html>
