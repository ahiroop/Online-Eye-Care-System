<?php

class ConnectionClass
{
  public function open()
  {
	    $mysql_hostname = "localhost";
		$mysql_user = "root";
		$mysql_password = "";
		$mysql_database = "onlineeyecare";
		$prefix = "";
		$bd = @mysql_connect($mysql_hostname, $mysql_user, $mysql_password) 
		or die(mysql_error());
		mysql_select_db($mysql_database, $bd) 
		or die("Could not select database");
        //require("siteasset/config.php");
	 //echo "<h1>"."Constructed Created"."</h1>";
	 
  }



  public function Manipulation($qry)
  {
   $this->open();
  $response =array();
   	try
	{
	
		$result=mysql_query($qry); 
		if($result)
		$response['Status']="true";
			 
		else
			throw new Exception(mysql_error());	
	
	}
	catch(Exception $e)
	{
	$response['Status']="false";
	$response['Message']= $e->getMessage();
		 
	}
    
	 mysql_close();
	 
	 return ($response);
	 
  }
 
  public function GetTable($qry) 
 {
	 $this->open();
 	try
	{
		$result=mysql_query($qry);// or throw new Exception("Error in Query");
		if($result)
		{
			$data = array(); // create a variable to hold the information
			while (($row = mysql_fetch_array($result, MYSQL_ASSOC)) !== false)
			{
				$data[] = $row; // add the row in to the results (data) array
		  
			}

			return $data;
		}
		else
			throw new Exception(mysql_error());	
	
	}
	catch(Exception $e)
	{
		return $e->getMessage();
	}
 	mysql_close();
 }
 
 
 
 
 
 
 
 
 public function GetSingleData($qry) 
 {
	 $this->open();
 	 try
	{
		$result=mysql_query($qry);// or throw new Exception("Error in Query");
		if($result)
		{
			//$data = array(); // create a variable to hold the information
			$row =@mysql_fetch_row($result) ;
			
			//	$data = $row; // add the row in to the results (data) array

			return $row[0];
		}
		else
			throw new Exception(mysql_error());	
	
	}
	catch(Exception $e)
	{
		return $e->getMessage();
	}
 	mysql_close($con);
 }
 
 public function GetSingleRow($qry) 
 {
	 $this->open();
 	 try
	{
		$result=mysql_query($qry);// or throw new Exception("Error in Query");
		if($result)
		{
			//$data = array(); // create a variable to hold the information
			$row = mysql_fetch_array($result) ;
			
			//	$data = $row; // add the row in to the results (data) array

			return $row;
		}
		else
			throw new Exception(mysql_error());	
	
	}
	catch(Exception $e)
	{
		return $e->getMessage();
	}
 	mysql_close($con);
 }







 public function GenerateID($qry,$num) 
 {
	 $this->open();
	try
	{
		$result=mysql_query($qry);// or throw new Exception("Error in Query");
		if($result)
		{
			//$data = array(); // create a variable to hold the information
			$row = mysql_fetch_row($result) ;
			if(empty($row[0]))
			{
				$maxid=($num+1);
			}
			else
			{
				$maxid=$row[0]+1;
				
			}
			//	$data = $row; // add the row in to the results (data) array

			return $maxid;
		}
		else 
			throw new Exception(mysql_error());	
	
	}
	catch(Exception $e)
	{
		return $e->getMessage();
	}
	mysql_close();
 }  
	function alert($msg, $url=null)
	  {
		 echo  "
		 <script type='text/javascript'>
		alert('".$msg."');
		location.href='".$url."';
		</script>";
	  } 
}

?>