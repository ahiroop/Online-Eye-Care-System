<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
</head>
<?php 
include("header.php");
session_start();
 

if($_SERVER["REQUEST_METHOD"] == "POST")	
{
	include 'dbconn.php';
	$pdt_type=$_POST['pdt_type'];
	
	echo $sql="select * from pdt_type where type='$pdt_type' ";
			$result=@mysqli_query($sql);
			$record=@mysqli_num_rows($result);
			if($record == 1)
			{
				$err ='true';
				echo '<script type="text/javascript"> alert("Duplicate Product Type");</script>';
			}
	if(!isset($err)) 
		 { 
	
		echo $sql="insert into pdt_type(type) values ('$pdt_type')";
		//echo $sql;
		@mysqli_query($sql) or die();
		echo '<script type="text/javascript"> alert("Successfully Add New Product Type");</script>';

	}
}
	?>
<body>

<center>
 <p>&nbsp;</p>
  <div class="services-heading">
				<h2>Add New Product Type</h2>
  </div>

<p>&nbsp;</p>
<p>&nbsp;</p>

<form  name="form1" method="post" >
  <table width="656" height="87">
    <tr>
      <th width="314" height="37" scope="row"><strong>Product Type </strong></th>
      <td width="330"><label>
        <input type="text" name="pdt_type" value="<?php if(isset($pdt_type)) echo $pdt_type; ?>" required />
      </label></td>
	  
    </tr>
   
	
  </table>
  <p>
    <label>
    <input type="submit" name="Submit" value="Add Product Type" />
    </label>
  </p>
</form>
<p>&nbsp;</p>
</center>
	<!-- footer -->
	<div class="w3-agile-footer">
		<div class="container">
			
			<div class="agileits-w3layouts-copyright">
				<p>� 2018 Online eye care . All Rights Reserved | Design by <a href="https://www.facebook.com/sreekutty.prakash.9"> SSSP</a> </p>
			</div>
		</div>
	</div>
	<!-- //footer -->
</body>
</html>
