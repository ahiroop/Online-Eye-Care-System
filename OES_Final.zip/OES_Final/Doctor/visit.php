<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

</head>
<?php 
session_start();
$id =$_SESSION["id"];
include("header.php"); ?>
<?php
include 'dbconn.php';
$app_id= $_REQUEST['app_id'];
$sql="update appointment set status='Visited' where app_id=$app_id";// echo $sql;
	mysql_query($sql) or die();

if($_SERVER["REQUEST_METHOD"] == "POST")	
{
	
	$medicine=$_POST['medicine'];
	$dosage=$_POST['dosage'];
	$noofDays=$_POST['noofDays'];
	$msg=$_POST['msg'];
	$date= date('Y-m-d');
	
	$sql="insert into prescription(medicines,noofDays,dosage,pat_id,doc_id,msg,m_date) values ('$medicine','$noofDays','$dosage','$pat_id','$id','$msg','$date')";
		//echo $sql;
		mysqli_query($con,$sql) or die();
		
		echo '<script type="text/javascript"> alert("Added...!");</script>';
	
}
	?>
<body>

<center>
 <p>&nbsp;</p>
  <div class="services-heading">
				<h2>Add Prescription</h2>
  </div>

<p>&nbsp;</p>
<p>&nbsp;</p>
<form  name="form1" method="post" >
  <table width="656" height="401">
    <tr>
      <th width="231" scope="row"> Name</th>
      <td width="153"><label>
        <input type="text" name="pat_name" value="<?php echo $pat_name; ?>" readonly="" />
      </label></td>
    </tr>
    <tr>
      <th scope="row">Medicine Name</th>
      <td><label>
      <input type="text" name="medicine"  required />
      </label></td>
    </tr>
   	<tr>
      <th scope="row">Dosage</th>
      <td><label>
      <input type="text" name="dosage"  required />
      </label></td>
    </tr>
	<tr>
      <th scope="row">No of Days</th>
      <td><label>
      <input type="text" name="noofDays"  required />
      </label></td>
    </tr>
    <tr>
      <th scope="row">Message</th>
      <td><label>
      <input type="text" name="msg"  required />
      </label></td>
    </tr>
	
  </table>
  <p>
    <label>
    <input type="submit" name="Submit" value="Add Prescription" />
    </label>
  </p>
</form>
<p>&nbsp;</p>
</center>
	
	<!-- footer -->
	<div class="w3-agile-footer">
		<div class="container">
			
			<div class="agileits-w3layouts-copyright">
				<p>� 2018 Online eye care . All Rights Reserved | Design by <a href="https://www.facebook.com/sreekutty.prakash.9"> SSSP</a> </p>
			</div>
		</div>
	</div>
	<!-- //footer -->
</body>
</html>
