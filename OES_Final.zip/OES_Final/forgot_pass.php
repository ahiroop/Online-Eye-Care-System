<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

</head>
<?php
include("header.php"); 
include 'dbconn.php';
session_start();
if($_SERVER["REQUEST_METHOD"] == "POST")	
{
		$loginid=$_POST['loginid'];
		$sql="select * from login where username='$loginid'";//echo $sql;
		$result=mysqli_query($con,$sql);
		$row=mysqli_fetch_array($result);
		$record=mysqli_num_rows($result);
		$id=$row['id'];
			if($record == 1)
			{
				$_SESSION["key"] = $id;
				header("location:newpass.php");
			}
			else
			{
				$err = "Incorrect LoginId";
			}
	}
	?>
<body>
 

<center>
<p>&nbsp;</p>
  <div class="services-heading">
				<h2>View Profile</h2>
  </div>

<p>&nbsp;</p>
<div class="well">
<form  name="form1" method="post" >
  <table width="598" height="106">
    <tr>
      <th width="193" height="100" scope="row"><div align="left">Enter your LoginId </div></th>
      <td width="193"><label>
        <div align="left"><input name="loginid" type="text" /></div>
      </label></td>
	  <td> <span style="color:#FF0000;"><?php if(isset($err)) echo $err; ?></span></td>
    </tr>
  
  </table>
 
  <p>
    <label>
    <input type="submit" name="Submit" value="Submit" />
    </label>
  </p>
  <div>
  <p><?php if(isset($pass)) echo $pass; ?></p>
  </div>
  </form>
</div>
<p>&nbsp;</p>
</center>
	<!-- footer -->
	<div class="w3-agile-footer">
		<div class="container">
			
			<div class="agileits-w3layouts-copyright">
				<p>� 2018 Online eye care . All Rights Reserved | Design by <a href="https://www.facebook.com/sreekutty.prakash.9"> SSSP</a> </p>
			</div>
		</div>
	</div>
	<!-- //footer -->
</body>
</html>
