<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    $(document).on('click','.show_more_main',function(){
        var ID = $(this).attr('doctor_id');
        $('.show_more').hide();
        $('.loding').show();
        $.ajax({
            type:'POST',
            url:'ajax_more.php',
            data:'doctor_id='+ID,
            success:function(html){
                $('#show_more_main'+ID).remove();
                $('.bs-docs-example wow fadeInUp animated').append(html);
            }
        });
    });
});
</script>
<style>
.list_item {
    background-color: #F1F1F1;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    margin: 5px 15px 2px;
    padding: 2px;
    font-size: 14px;
    line-height: 1.5;
}
.show_more_main {
    margin: 15px 25px;
}
.show_more {
    background-color: #f8f8f8;
    background-image: -webkit-linear-gradient(top,#fcfcfc 0,#f8f8f8 100%);
    background-image: linear-gradient(top,#fcfcfc 0,#f8f8f8 100%);
    border: 1px solid;
    border-color: #d3d3d3;
    color: #333;
    font-size: 12px;
    outline: 0;
}
.show_more {
    cursor: pointer;
    display: block;
    padding: 10px 0;
    text-align: center;
    font-weight:bold;
}
.loding {
    background-color: #e9e9e9;
    border: 1px solid;
    border-color: #c6c6c6;
    color: #333;
    font-size: 12px;
    display: block;
    text-align: center;
    padding: 10px 0;
    outline: 0;
    font-weight:bold;
}
.loding_txt {
    background-image: url(loading.gif);
    background-position: left;
    background-repeat: no-repeat;
    border: 0;
    display: inline-block;
    height: 16px;
    padding-left: 20px;
}
}

</style>
</head>
<?php
session_start();
//session_start();
include("header.php"); 
include 'dbconn.php';
?>
<body>

<center>
 <p>&nbsp;</p>
  <div class="services-heading">
				<h2>View Doctor</h2>
  </div>

<p>&nbsp;</p>
<p>&nbsp;</p>

  <div class="bs-docs-example wow fadeInUp animated" data-wow-delay=".5s">
  <table width="420" height="104" class="table">
  <thead>
    <tr>
      <th ><strong>Sl. No. </strong></th>
      <th><strong>Name</strong></th>
	  <th><strong>Category</strong></th>
     <th><strong>Email</strong></th>
      <th><strong>Contact No. </strong></th>
      
    </tr>
	</thead>
	<tbody>
	<?php
			echo $sql1="SELECT * FROM (SELECT * FROM doctor ORDER BY doctor_id DESC LIMIT 5) sub ORDER BY doctor_id ASC;";
			$result=mysqli_query($con,$sql1);
			if($result->num_rows>0){ 
            while($row=$result->fetch_assoc()){ 
           echo $doc_id=$row['doctor_id'];
			$s =0;
			$s=$s+1;
	?>
	<?php  } ?>
    <tr>
      <td><?php echo $s;?>&nbsp;</td>
      <td><?php echo $row['doctor_name'];?>&nbsp;</td>
	  <td><?php echo $row['category'];?>&nbsp;</td>
      <td><?php echo $row['email_id'];?>&nbsp;</td>
      <td><?php echo $row['phone']; ?>&nbsp;</td>
     
    </tr>
	
	<?php  } ?>
	</tbody>
  </table>
  </div>
   <div class="show_more_main" id="show_more_main<?php echo $doc_id;?>">
   <span id="<?php echo $doc_id; ?>" class="show_more" title="Load more posts">Show more</span>
        <span class="loding" style="display: none;"><span class="loding_txt">Loading...</span></span>
</div>
<p>&nbsp;</p>
</center>
</body>
</html>
			
	<!--<!-- footer -->
	<!--<div class="w3-agile-footer">
		<div class="container">
			
			<div class="agileits-w3layouts-copyright">
				<p>� 2018 Online eye care . All Rights Reserved | Design by <a href="https://www.facebook.com/sreekutty.prakash.9"> SSSP</a> </p>
			</div>
		</div>
	</div>
	<!-- //footer -->

