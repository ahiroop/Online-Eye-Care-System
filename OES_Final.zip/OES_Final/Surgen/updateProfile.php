<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

</head>
<?php
session_start();

include("header.php"); 
include 'dbconn.php';
require_once("../ConnectionClass.php");
$obj= new ConnectionClass();
$username=$_SESSION['username'];
echo $sql1="select s_id from surgen where email='$username'";
echo $c1=$obj->GetSingleData($sql1);
//$id =$_SESSION["id"];

		
if($_SERVER["REQUEST_METHOD"] == "POST")	
{
	
	$name=$_POST['name'];
	if(!preg_match("/^[a-zA-Z ]*$/",$name))
		{
			$nameErr="Name contain lettters and white space";
			$status="true";
		}
	$email=$_POST['email'];
	if(!preg_match("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$^",$email))
		{
			$emailErr="Invaild Email Id";
			$status="true";
		}
	$phone=$_POST['phone'];
	if(!preg_match("/^[0-9]{10}$/",$phone))
		{
			$phnErr="Phone Number contain 10 digits";
			$status="true";
		}
	//$branch_id=$_POST['branch_id'];
/*	if($branch_id == "-Select-") 
	{
	$status="true";
	echo '<script type="text/javascript"> alert("Select Branch");</script>';
	}*/
	

	
	if(!isset($status))
	{
		$sql="update surgen set name='$name',email='$email',phone='$phone' where s_id=$c1";
		//echo $sql;
		mysqli_query($con,$sql) or die();
		echo '<script type="text/javascript"> alert("Successfully Updated..!");</script>';
	}
	
}
$sql="select * from surgen where s_id=$c1";// echo $sql;
		$result=@mysqli_query($con,$sql);
		$row=@mysqli_fetch_array($result);

	?>
<body>

<center>
 <p>&nbsp;</p>
  <div class="services-heading">
				<h2>Update Profile</h2>
  </div>

<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<form  name="form1" method="post" >
  <table width="791" height="213">
    <tr>
      <th width="254" scope="row"> Name</th>
      <td width="242"><label>
        <input type="text" name="name" value="<?php echo $row["name"]; ?>" required />
      </label></td>
	   <td width="279"> <span style="color:#FF0000;">
      <?php if(isset($nameErr)) echo $nameErr; ?>
      </span></td>
    </tr>
   
    <tr>
      <th scope="row">Email Id </th>
      <td><label>
      <input type="email" name="email" value="<?php echo $row["email"]; ?>" required />
      </label></td>
	   <td width="240"><span style="color:#FF0000;">
  <?php if(isset($emailErr)) echo $emailErr; ?>
  </span></td>
    </tr>
	 <tr>
      <th scope="row">Phone Number </th>
      <td><label>
      <input type="text" name="phone" value="<?php echo $row["phone"]; ?>" required />
      </label></td>
	  <td width="279"> <span style="color:#FF0000;">
      <?php if(isset($phnErr)) echo $phnErr; ?>
      </span></td>
    </tr>
   
    
  </table>
  <p>
    <label>
    <input type="submit" name="Submit" value="Update Profile" />
    </label>
  </p>
</form>
<p>&nbsp;</p>
</center>
	
	<!-- footer -->
	<div class="w3-agile-footer">
		<div class="container">
			
			<div class="agileits-w3layouts-copyright">
				<p>� 2018 Online eye care . All Rights Reserved | Design by <a href="https://www.facebook.com/sreekutty.prakash.9"> SSSP</a> </p>
			</div>
		</div>
	</div>
	<!-- //footer -->
</body>
</html>
