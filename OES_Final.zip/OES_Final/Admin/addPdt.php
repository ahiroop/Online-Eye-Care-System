<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

</head>
<?php 
require_once("../ConnectionClass.php");
$obj= new ConnectionClass();
include"header.php"; 
include 'dbconn.php';
session_start();
if($_SERVER["REQUEST_METHOD"] == "POST")	
{
	$name=$_POST['pdt_name'];
	$pdt_name=$_POST['product'];
	$model=$_POST['model'];
	//$type_id=$_POST['type_id'];
	//if($type_id == "-Select-") 
	//{//
	//$status="true";
	//$typeErr="Select Type";
	//}//
	
	$qty=$_POST['qty'];
	$cost=$_POST['cost'];
	//$stock=$_POST['total'];
	//$total=$qty+$stock;
	//echo $s="update product set total='$total'";
	//echo $da=$obj->GetSingleData($s);
	//image dir
	$target_dir = "../uploads/";
	$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
	$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
	
	if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
		&& $imageFileType != "gif" ) {
			$imgErr = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
			$status = 1;
		}
		
  

	if(!isset($status))
	{
	// upload image to folder
	
	$sql="select * from product where pdt_name='$pdt_name' and pdt_model='$model'";
			$result=@mysqli_query($con,$sql);
			$record=@mysqli_num_rows($result);
			if($record == 1)
			{
				$err ='true';
				echo '<script type="text/javascript"> alert("Duplicate Product Details");</script>';
			}
	if(!isset($err)) 
		 { 
		 move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file);
		$sql="insert into product(pdt_name,pdt_type,pdt_model,pdt_qty,pdt_cost,pic) values ('$name','$pdt_name','$model','$qty','$cost','$target_file')";
		//echo $sql;
		@mysqli_query($con,$sql) or die();
		
		echo '<script type="text/javascript"> alert("Successfully added New product");</script>';
		}
	}
	
}
	?>
<body>

<center>
 <p>&nbsp;</p>
  <div class="services-heading">
				<h2> Add New Product</h2>
  </div>

<p>&nbsp;</p>
<p>&nbsp;</p>
<form  name="form1" method="post" enctype="multipart/form-data" >
  <table width="656" height="401">
    <tr>
      <th width="231" scope="row">Product Name</th>
      <td width="153"><label>
        <input type="text" name="pdt_name" value="<?php if(isset($pdt_name)) echo $pdt_name; ?>" required />
      </label></td>
	  
	
    </tr>
   <tr>
      <th width="231" scope="row">Product Type</th>
      <td width="153"><label>
	  
		<select name="product">
		<option>---Select Type--</option>
		 <option value="Eye Glasses">Eye Glasses</option>
		 <option value="Premium Eye Glasses">Premium Eye Glasses</option>
		 <option value="Sun Glasses">Sun Glasses</option>
		 <option value="Power Sun Glasses">Power Sun Glasses</option>
		 <option value="Contact Lenses">Contact Lenses</option>
		 
 
 </select>
	  
        <!--<select name="type_id">
		<option>-Select-</option>
			<//?php $sql="select * from pdt_type";
			$result=@mysql_query($sql);
			$records=@mysql_num_rows($result);
			while($row=@mysql_fetch_array($result))
			{?>
			<option value="</?php echo $row['type_id']; ?>"></?php echo $row['type']; ?></option>
			<//?php } ?>
		</select>
      </label></td>
	  <td> <span style="color:#FF0000;">
      <//?php if(isset($typeErr)) echo $typeErr; ?>
      </span>-->
	  </td>
    </tr>
   
    <tr>
      <th scope="row">Model </th>
      <td><label>
      <input type="text" name="model" value="<?php if(isset($model)) echo $model; ?>" required />
      </label></td>
    </tr>
   
    <tr>
      <th scope="row">Quantity</th>
      <td><label>
	         <input type="text" name="qty"  value="<?php if(isset($qty)) echo $qty; ?>"required />
      </label></td>
    </tr>
	<tr>
      <th scope="row">Cost</th>
      <td><label>
      <input type="text" name="cost"  value="<?php if(isset($cost)) echo $cost; ?>" required />
      </label></td>
    </tr>
   		<tr>
      <th scope="row"> Select image to upload:</th>
      <td><label>
        <input type="file" name="fileToUpload" id="fileToUpload">
      </label></td>
    </tr>
	
  </table>
  <p>&nbsp;</p>
  <p>
    <label>
      <input type="submit" name="Submit" value="ADD NEW PRODUCT" />
      </label>
  </p>
  <p>&nbsp;</p>
</form>
<p>&nbsp;</p>
</center>
	<!-- footer -->
	<div class="w3-agile-footer">
		<div class="container">
			
			<div class="agileits-w3layouts-copyright">
				<p>� 2018 Online eye care . All Rights Reserved | Design by <a href="https://www.facebook.com/sreekutty.prakash.9"> SSSP</a> </p>
			</div>
		</div>
	</div>
	<!-- //footer -->
</body>
</html>
