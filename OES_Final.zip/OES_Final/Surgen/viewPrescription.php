<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

</head>
<?php
session_start();
 
include("header.php"); 
include 'dbconn.php';
//$id =$_SESSION["id"];
$pat_id= $_REQUEST['pat_id'];

$sq="select * from patient where pat_id=$pat_id"; //echo $sql;
			$re=mysqli_query($con,$sq); 
			$r=mysqli_fetch_array($re);
			$name= $r['pat_name'];
?>
<body>

<center>
 <p>&nbsp;</p>
  <div class="services-heading">
				<h2>View Prescription</h2>
  </div>

<p>&nbsp;</p>
<p>&nbsp;</p>

<form  name="form1" method="post" >

  <p> Name :<b><?php echo $name; ?></b>&nbsp;</p>
  <table width="744" height="89" border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td height="46"><div align="center"><strong>Sl. No. </strong></div></td>
      <td><div align="center"><strong>Medicine Name</strong></div></td>
      <td><div align="center"><strong>Dosage</strong></div></td>
      <td><div align="center"><strong>No. of Days </strong></div></td>
      <td><div align="center"><strong>Message</strong></div></td>
    </tr>
	 <?php 
	 /*details of approved patients */
  	$sql="select * from surgenprescription where pat_id=$pat_id"; //echo $sql;
	$result=mysqli_query($con,$sql);
	$s =0;
 	while($row=mysqli_fetch_array($result))
	{
			$s=$s+1;			
  ?>
    <tr>
      <td><div align="center"><?php echo $s; ?>&nbsp;</div></td>
      <td><div align="center"><?php echo $row['medicines']; ?>&nbsp;</div></td>
      <td><div align="center"><?php echo $row['dosage']; ?>&nbsp;</div></td>
      <td><div align="center"><?php echo $row['noofdays']; ?>&nbsp;</div></td>
	  <td><div align="center"><?php echo $row['msg']; ?>&nbsp;</div></td>
    </tr>
	<?php  } ?>
	
  </table>
  <p>&nbsp;</p>
  <p><a href="addPrescription.php?pat_id=<?php echo $pat_id; ?>"></a>
  </p>
  <div >
  <p><a href="pat_details.php?pat_id=<?php echo $r['pat_id']; ?>"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</a></p>
  </div>
</form>
<p>&nbsp;</p>
</center>
	
	<!-- footer -->
	<div class="w3-agile-footer">
		<div class="container">
			
			<div class="agileits-w3layouts-copyright">
				<p>� 2018 Online eye care . All Rights Reserved | Design by <a href="https://www.facebook.com/sreekutty.prakash.9"> SSSP</a> </p>
			</div>
		</div>
	</div>
	<!-- //footer -->
</body>
</html>
