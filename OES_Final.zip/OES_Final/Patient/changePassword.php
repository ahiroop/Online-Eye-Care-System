<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php
include 'header.php';
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

</head>
<body>

<center>
 <p>&nbsp;</p>
  <div class="services-heading">
				<h2>Change Password</h2>
  </div>

<p>&nbsp;</p>
<p>&nbsp;</p>

<form action="passwordverify.php" name="form1" method="post" >
  <table width="791" height="182">
    <tr>
      <th width="254" scope="row">Current Password</th>
      <td width="242"><label>
        <input type="password" name="oldPassword" required />
      </label></td>
    </tr>
    <tr>
      <th width="254" scope="row">New Password</th>
      <td width="242"><label>
         <input type="password" name="password" required />
      </label></td>
    </tr>
   
    <tr>
      <th height="73" scope="row">Confirm Password </th>
      <td><label>
      <input type="password" name="cpassword" required />
     </label></td>
	 <td> <span style="color:#FF0000;">
      </span></td>
    </tr>
   
    
  </table>
  <p>&nbsp;</p>
  <p>
    <label>
      <input type="submit" name="Submit" value="Submit" />
      </label>
  </p>
  <p>&nbsp;</p>
</form>
<p>&nbsp;</p>
</center>
	
	<!-- footer -->
	<div class="w3-agile-footer">
		<div class="container">
			
			<div class="agileits-w3layouts-copyright">
				<p>� 2018 Online eye care . All Rights Reserved | Design by <a href="https://www.facebook.com"> SSSP</a> </p>
			</div>
		</div>
	</div>
	<!-- //footer -->
</body>
</html>
