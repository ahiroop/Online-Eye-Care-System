<?php
session_start();
$username=$_SESSION['username'];
$currentpassword=$_SESSION['password'];
$password_chk=$_POST['oldPassword'];
$new_pass1=$_POST['password'];
$new_pass2=$_POST['cpassword'];
require_once("../ConnectionClass.php");
$obj= new ConnectionClass();

if ($currentpassword==$password_chk)
{
	if ($new_pass1==$new_pass2)
	{
		echo $qry="update login set password='$new_pass1' where username='$username'";
		$result=$obj->Manipulation($qry);
		if ($result['Status']=="true") 
		{
			$obj->alert("Password Sucessfully Updated","logout.php");
		}
		else
		{
			//echo $result['Message'];
		}
	}
	else
	{
		//echo "pass no match";
		$obj->alert("pass no match","changePassword.php");
	}
}
else
{
	//echo "curr pass incorrect";
	//$obj->alert("current password incorrect","change password.php");
}
?>