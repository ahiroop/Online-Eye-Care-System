<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

</head>
<?php
session_start();
require_once("../ConnectionClass.php");
$obj= new ConnectionClass();
include("header.php"); 
include 'dbconn.php';
echo $pdt_id =$_REQUEST["pdt_id"];
$username=$_SESSION['username'];
$sql="select pdt_qty from product where pdt_id='$pdt_id'";
$c=$obj->GetSingleData($sql);
echo $sql1="select pat_id from patient where email_id='$username'";
echo $c1=$obj->GetSingleData($sql1);


if($_SERVER["REQUEST_METHOD"] == "POST")	
{
	$sql="select pdt_qty from product where pdt_id='$pdt_id'";
	$c=$obj->GetSingleData($sql);
	$quantity=$_POST['quantity'];//patient needs
	echo $stock=$c-$quantity;//balance stock
	if($stock>=0)
	{
	// update stock
	$sql="update product set pdt_qty='$stock' where pdt_id=$pdt_id";
		//echo $sql;
		mysqli_query($con,$sql) or die();
		
		//add order
		$sql="insert into orderpdt(pdt_id,pat_id,qty) values ('$pdt_id','$c1','$quantity')";
		//echo $sql;
		mysqli_query($con,$sql) or die();
		
		echo '<script type="text/javascript"> alert("order placed..!");</script>';
	}
	else
	{
		echo '<script type="text/javascript"> alert("stock closed..!");</script>';
	}
}
	else
	{
		//echo $err="enter the quantity less than a stock";
	}
	

	
$sql="select * from product where pdt_id=$pdt_id";// echo $sql;
		$result=mysqli_query($con,$sql);
		$row=mysqli_fetch_array($result);

	?>
<body>
 

<center>
<p>&nbsp;</p>
  <div class="services-heading">
				<h2>Add Stock</h2>
  </div>

<p>&nbsp;</p>
<div class="well">
<form  name="form1" method="post" >
  <p><img src="<?php echo $row["pic"]; ?> " alt="pdt image" name="pic" width="539" height="374" id="pic" /></p>
  <table width="398" height="163">
    <tr>
      <th width="193" scope="row"><div align="left"> Name</div></th>
      <td width="193"><label>
        <div align="left"><?php echo $row["pdt_name"]; ?>          </div>
      </label></td>
    </tr>
    <tr>
      <th width="193" scope="row"><div align="left">Product Type </div></th>
      <td width="193"><label>
        <div align="left">
          <?php 
			$s="select pdt_type from product where pdt_id=$pdt_id";	
           echo $u=$obj->GetSingleData($s);
		?>
          </div>
      </label></td>
    </tr>
    <tr>
      <th scope="row"><div align="left">Model</div></th>
      <td><label>
      <div align="left"><?php echo $row["pdt_model"]; ?>      </div>
      </label></td>
    </tr>
	 <tr>
      <th scope="row"><div align="left">Specfication</div></th>
      <td><label>
      <div align="left"><?php echo $row["pdt_qty"]; ?>      </div>
      </label></td>
    </tr>
    <tr>
      <th scope="row"><div align="left">Cost</div></th>
      <td><label>
      <div align="left"><?php echo $row["pdt_cost"]; ?>      </div>
      </label></td>
    </tr>
	 <tr>
      <th scope="row"><div align="left">Quantity</div></th>
      <td><label>
      <div align="left"><input name="quantity" type="text"   />  <span style="color:#FF0000"><?php if(isset($err)) echo $err; ?> </span>    </div>
      </label></td>
    </tr>
  </table>
  
  <p>
    <label>
    <input type="submit" name="Submit" value="Book" />
    </label>
  </p>
  <p><a href="pdt_view.php"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</a></p>
  <p>&nbsp;</p>
</form>
</div>
<p>&nbsp;</p>
</center>
	<!-- footer -->
	<div class="w3-agile-footer">
		<div class="container">
			
			<div class="agileits-w3layouts-copyright">
				<p>� 2018 Online eye care . All Rights Reserved | Design by <a href="https://www.facebook.com/"> SSSP</a> </p>
			</div>
		</div>
	</div>
	<!-- //footer -->
</body>
</html>
