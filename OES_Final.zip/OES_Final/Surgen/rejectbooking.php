<?php 
session_start(); 
//$id= $_SESSION["id"]; // echo $userId;
include 'dbconn.php';
$sapp_id=$_REQUEST['sapp_id'];
$sql="update surgenappointment set status='Rejected' where sapp_id=$sapp_id";
		mysqli_query($con,$sql) or die();
		header("location:viewBooking.php");
?>