-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 08, 2019 at 07:31 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.1.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlineeyecare`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(10) NOT NULL,
  `admin_name` varchar(50) NOT NULL,
  `branch_id` varchar(50) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `lastlogin` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_name`, `branch_id`, `email_id`, `lastlogin`) VALUES
(1, 'Admin', '1', 'admin11@gmail.com', ''),
(2, 'Sreekutty', '2', 'sree@gmail.com', ''),
(3, 'Sara', '2', 'sara@gmail.com', ''),
(4, 'adminj', '3', 'admin3@gmail.com', '');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `app_id` int(10) NOT NULL,
  `pat_id` varchar(50) NOT NULL,
  `doctor_id` varchar(50) NOT NULL,
  `branch_id` varchar(50) NOT NULL,
  `bdate` varchar(50) NOT NULL,
  `btime` varchar(50) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`app_id`, `pat_id`, `doctor_id`, `branch_id`, `bdate`, `btime`, `status`) VALUES
(4, '1', '2', '2', '2018-11-20', '11:30 am', 'Visited'),
(5, '2', '4', '3', '2018-10-27', '5:00 pm', 'Pending'),
(6, '1', '2', '2', '2018-11-08', '5:15 pm', 'Rejected'),
(7, '1', '4', '3', '2018-11-08', '11.00 am', 'Cancel'),
(8, '1', '2', '2', '2018-11-21', '5:15 pm', 'Visited'),
(9, '1', '2', '2', '2018-11-12', '4:00 pm', 'Approved'),
(10, '1', '3', '3', '2018-11-13', '11:15 am', 'Pending'),
(11, '2', '2', '2', '2018-11-24', '12:45 pm', 'Approved'),
(12, '1', '2', '2', '2018-11-19', '5:30 pm', 'Approved'),
(13, '1', '3', '3', '2018-11-20', '12:30 pm', 'Pending'),
(14, '1', '4', '3', '2018-11-24', '5:15 pm', 'Cancel'),
(15, '7', '2', '2', '2019-02-21', '12:00 pm', 'Rejected'),
(16, '8', '2', '1', '2019-02-27', '10:00 am', 'Approved'),
(17, '10', '2', '1', '2019-02-28', '10:00 am', 'Visited'),
(18, '13', '2', '1', '2019-03-20', '5:00 pm', 'Rejected'),
(19, '13', '2', '1', '2019-03-21', '5:00 pm', 'Approved'),
(20, '14', '2', '1', '2019-04-08', '11:00 am', 'Visited');

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE `bill` (
  `bill_id` int(10) NOT NULL,
  `billno` varchar(30) NOT NULL,
  `pat_id` varchar(50) NOT NULL,
  `ddate` varchar(50) NOT NULL,
  `amount` varchar(50) NOT NULL,
  `doc_id` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bill`
--

INSERT INTO `bill` (`bill_id`, `billno`, `pat_id`, `ddate`, `amount`, `doc_id`) VALUES
(1, '7360840', '1', '2018-11-20', '700', '2'),
(2, '7348938', '1', '2018-11-20', '099', '2'),
(3, '9633179', '1', '2018-11-21', '300', '2'),
(4, '3640909', '10', '2019-02-28', '500', '2'),
(5, '9109534', '14', '2019-04-08', '500', '2');

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `branch_id` int(10) NOT NULL,
  `branch_name` varchar(50) NOT NULL,
  `description` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`branch_id`, `branch_name`, `description`) VALUES
(1, 'Kottayam Main Branch', 'Main Branch'),
(2, 'Aym Branch', 'Sub Branch'),
(3, 'TB Road Branch', 'Sub Branch'),
(4, 'Palakad', 'Sub branch');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `doctor_id` int(10) NOT NULL,
  `doctor_name` varchar(50) NOT NULL,
  `branch_id` varchar(50) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`doctor_id`, `doctor_name`, `branch_id`, `email_id`, `phone`) VALUES
(2, 'Sara', '1', 'sara@gamil.com', '2383456765'),
(3, 'Manu ', '3', 'manu@gmail.com', '2234545454'),
(4, 'Geethu S', '3', 'geethu@gmail.com', '2234545454'),
(5, 'Aswani', '2', 'aswani@gmail.com', '7845123265');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(10) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `loginid` varchar(20) NOT NULL,
  `type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`, `loginid`, `type`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '1', 'Admin'),
(2, 'sree', 'cf69812a3e3e1cf4818231ca4b58fe6c', '2', 'Admin'),
(5, 'sara', '202cb962ac59075b964b07152d234b70', '2', 'Doctor'),
(6, 'neethu', '8abfb0df43eefc49ceaa0df35136649e', '1', 'Patient'),
(7, 'jinu', 'b3d84ebbaad735ccb91a539ecc3c4d34', '2', 'Patient'),
(8, 'jithu', '97e75fd1f9125270c4ec644141947574', '3', 'Patient'),
(9, 'manu', 'f13bb1bed03db9d68a7d9a48aafeec78', '3', 'Doctor'),
(10, 'geethu', '4045f56cd6a8d853f2fd7d66cffad1bf', '4', 'Doctor'),
(12, 'achunnnn', '0a113ef6b61820daa5611c870ed8d5ee', '', 'Patient'),
(13, 'jjjj', '202cb962ac59075b964b07152d234b70', '7', 'Patient'),
(14, 'admin3', '698d51a19d8a121ce581499d7b701668', '4', 'Admin'),
(15, 'aswani', '202cb962ac59075b964b07152d234b70', '5', 'Doctor'),
(16, 'achu', '698d51a19d8a121ce581499d7b701668', '8', 'Patient'),
(17, 'asa', '698d51a19d8a121ce581499d7b701668', '9', 'Patient'),
(18, 'anna', '202cb962ac59075b964b07152d234b70', '10', 'Patient'),
(19, 'umesh', '202cb962ac59075b964b07152d234b70', '11', 'Patient'),
(20, 'amith', '202cb962ac59075b964b07152d234b70', '12', 'Patient'),
(21, '1', '202cb962ac59075b964b07152d234b70', '13', 'Patient'),
(22, 'balu', '202cb962ac59075b964b07152d234b70', '14', 'Patient');

-- --------------------------------------------------------

--
-- Table structure for table `orderpdt`
--

CREATE TABLE `orderpdt` (
  `ord_id` int(10) NOT NULL,
  `pdt_id` varchar(20) NOT NULL,
  `pat_id` varchar(20) NOT NULL,
  `qty` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orderpdt`
--

INSERT INTO `orderpdt` (`ord_id`, `pdt_id`, `pat_id`, `qty`) VALUES
(1, '1', '1', '1'),
(2, '2', '1', '5'),
(3, '5', '1', '2'),
(4, '1', '10', '1'),
(5, '2', '10', '1'),
(6, '2', '14', '2');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `pat_id` int(10) NOT NULL,
  `pat_name` varchar(50) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `created_at` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`pat_id`, `pat_name`, `email_id`, `dob`, `gender`, `address`, `contact`, `created_at`) VALUES
(1, 'Neethu', 'neethus@gmail.com', '2002-07-18', 'Female', 'kty', '2383456768', '2018-10-22'),
(2, 'jinu joseph', 'josephjinu20657@gmail.com', '1995-11-03', 'Female', 'kadumbukalayil', '8138873534', '2018-10-24'),
(3, 'jithu joseph', 'jithujoseph@gmail.com', '2000-01-29', 'Male', 'kadumbukala', '8156920350', '2018-10-24'),
(4, 'nbh', 'gigi@gmail.com', '2018-11-30', 'Male', 'knjk', '7845123265', '2019-02-20'),
(5, 'Achu', 'achu@gmail.com', '2018-11-30', 'Female', 'kply', '7845123265', '2019-02-20'),
(6, 'Achunn', 'achu@gmail.com', '2018-11-30', 'Male', 'kply', '7845123265', '2019-02-20'),
(7, 'Achunndd', 'achu@gmail.com', '2018-11-30', 'Male', 'kply', '7845123265', '2019-02-20'),
(8, 'Achu', 'achu@gmail.com', '2018-12-11', 'Female', 'achu@gmail.com', '5689741225', '2019-02-26'),
(9, 'afaf', 'gigi@gmail.com', '2019-02-17', 'Male', 'dasfsafa', '4512784512', '2019-02-26'),
(10, 'anna', 'anna@gmail.com', '2019-02-17', 'Female', 'adaaa', '4512784512', '2019-02-26'),
(11, 'umesh', 'umesh@gmail.com', '2019-03-13', 'Male', 'kottayam', '7845123265', '2019-03-19'),
(12, 'ammith', 'amith@gmail.com', '2019-03-04', 'Male', 'kottayam', '7845123696', '2019-03-19'),
(13, 'qwerty', 'a@agg.com', '2019-03-19', 'Male', 'ktm', '0123456789', '2019-03-19'),
(14, 'balu', 'balu@gmail.com', '2019-04-04', 'Male', 'ggjh', '7845123265', '2019-04-07');

-- --------------------------------------------------------

--
-- Table structure for table `pdt_type`
--

CREATE TABLE `pdt_type` (
  `type_id` int(10) NOT NULL,
  `type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pdt_type`
--

INSERT INTO `pdt_type` (`type_id`, `type`) VALUES
(1, 'Eye Glasses'),
(2, 'Premium Eye Glasses'),
(3, 'Sun Glasses'),
(4, 'Power Sun Glasses'),
(5, 'Contact Lenses');

-- --------------------------------------------------------

--
-- Table structure for table `prescription`
--

CREATE TABLE `prescription` (
  `pre_id` int(10) NOT NULL,
  `medicines` varchar(40) NOT NULL,
  `noofDays` varchar(20) NOT NULL,
  `dosage` varchar(50) NOT NULL,
  `pat_id` varchar(20) NOT NULL,
  `doc_id` varchar(20) NOT NULL,
  `msg` varchar(50) NOT NULL,
  `m_date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prescription`
--

INSERT INTO `prescription` (`pre_id`, `medicines`, `noofDays`, `dosage`, `pat_id`, `doc_id`, `msg`, `m_date`) VALUES
(1, 'f', 'gf', 'fg', '1', '2', 'gf', '2018-11-12'),
(2, 'tyrty', 'yrtyt', 'rtyrtyt', '1', '2', 'tyryt', '2018-11-13'),
(3, 'fg', '45', 'gghtry', '1', '2', 'ghbfgbng', '2018-11-20'),
(4, 'dff', 'df', 'fd', '1', '2', 'fd', '2018-11-21'),
(5, 'Eye drops', '5', '2 drops/2times', '10', '2', 'Review after 5 days', '2019-02-28'),
(6, 'Eye drops', '5', '2 drops/2times', '14', '2', 'Review after 5 days', '2019-04-08');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `pdt_id` int(20) NOT NULL,
  `pdt_name` varchar(50) NOT NULL,
  `pdt_type` varchar(50) NOT NULL,
  `pdt_model` varchar(50) NOT NULL,
  `pdt_qty` varchar(50) NOT NULL,
  `pdt_cost` varchar(50) NOT NULL,
  `stock` varchar(50) NOT NULL,
  `pic` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pdt_id`, `pdt_name`, `pdt_type`, `pdt_model`, `pdt_qty`, `pdt_cost`, `stock`, `pic`) VALUES
(1, 'Bausch & Lomb', '5', 'Soflens 59', '6 per Pack', '1200', '8', '../uploads/hamburger.jpg'),
(2, 'Ray - Ban', '1', 'DU Rx6303', '1 pdt', '3599', '5', '../uploads/23324.jpg'),
(3, 'carrera', '1', '168/V', '1 pdt', '7500', '11', '../uploads/wefref.jpg'),
(4, 'Tommy-hilfiger', '2', 'TH6122', '1 pdt', '6500', '5', '../uploads/sdfdfsd.jpg'),
(5, 'Vincent Chase', '3', 'VC 5158', '1 pdt', '3600', '3', '../uploads/456576.jpg'),
(6, 'Half Rim', '3', 'VC S11447', '1 pdt', '999', '5', '../uploads/23r53443.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `test_id` int(10) NOT NULL,
  `tDate` varchar(50) NOT NULL,
  `test` varchar(50) NOT NULL,
  `report` varchar(50) NOT NULL,
  `review` varchar(50) NOT NULL,
  `pat_id` varchar(50) NOT NULL,
  `doc_id` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`test_id`, `tDate`, `test`, `report`, `review`, `pat_id`, `doc_id`) VALUES
(1, '2018-11-12', 'blood group', '0+ve', 'O+ve', '1', '2'),
(2, '2018-11-21', 'g', 'gh', 'gh', '1', '2'),
(3, '2019-02-28', 'Eye test', 'short site', 'use spex', '10', '2'),
(4, '2019-04-08', 'Eye test', 'short site', 'use spex', '14', '2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`app_id`);

--
-- Indexes for table `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`bill_id`);

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`branch_id`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`doctor_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orderpdt`
--
ALTER TABLE `orderpdt`
  ADD PRIMARY KEY (`ord_id`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`pat_id`);

--
-- Indexes for table `pdt_type`
--
ALTER TABLE `pdt_type`
  ADD PRIMARY KEY (`type_id`);

--
-- Indexes for table `prescription`
--
ALTER TABLE `prescription`
  ADD PRIMARY KEY (`pre_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`pdt_id`);

--
-- Indexes for table `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`test_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `app_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `bill`
--
ALTER TABLE `bill`
  MODIFY `bill_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `branch`
--
ALTER TABLE `branch`
  MODIFY `branch_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `doctor_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `orderpdt`
--
ALTER TABLE `orderpdt`
  MODIFY `ord_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `pat_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `pdt_type`
--
ALTER TABLE `pdt_type`
  MODIFY `type_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `prescription`
--
ALTER TABLE `prescription`
  MODIFY `pre_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `pdt_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `test`
--
ALTER TABLE `test`
  MODIFY `test_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
