<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

</head>
<?php
session_start();
require_once("../ConnectionClass.php");
$obj= new ConnectionClass();
$username=$_SESSION['username'];
include("header.php"); 
include 'dbconn.php';
//$id =$_SESSION["id"];
echo $sql1="select pat_id from patient where email_id='$username'";
echo $c1=$obj->GetSingleData($sql1);
		
if($_SERVER["REQUEST_METHOD"] == "POST")	
{
	
	$pat_name=$_POST['pat_name'];
	if(!preg_match("/^[a-zA-Z ]*$/",$pat_name))
		{
			$nameErr="Name contain lettters and white space";
			$status="true";
		}
	$email_id=$_POST['email'];
	if(!preg_match("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$^",$email_id))
		{
			$emailErr="Invaild Email Id";
			$status="true";
		}
	$contact=$_POST['contact'];
	if(!preg_match("/^[0-9]{10}$/",$contact))
		{
			$phnErr="Phone Number contain 10 digits";
			$status="true";
		}
	$address=$_POST['address'];
	
/*	if($branch_id == "-Select-") 
	{
	$status="true";
	echo '<script type="text/javascript"> alert("Select Branch");</script>';
	}*/
	

	
	if(!isset($status))
	{
		$sql="update patient set pat_name='$pat_name',email_id='$email_id',address='$address',contact='$contact' where pat_id=$c1";
		//echo $sql;
		mysqli_query($con,$sql) or die();
		echo '<script type="text/javascript"> alert("Successfully Updated..!");</script>';
	}
	
}
$sql="select * from patient where pat_id=$c1";// echo $sql;
		$result=mysqli_query($con,$sql);
		$row=mysqli_fetch_array($result);

	?>
<body>

<center>
 <p>&nbsp;</p>
  <div class="services-heading">
				<h2>Update Profile</h2>
  </div>

<p>&nbsp;</p>
<p>&nbsp;</p>

<form  name="form1" method="post" >
  <table width="791" height="258">
    <tr>
      <th width="254" scope="row"> Name</th>
      <td width="242"><label>
        <input type="text" name="pat_name" value="<?php echo $row["pat_name"]; ?>" required />
      </label></td>
	   <td width="279"> <span style="color:#FF0000;">
      <?php if(isset($nameErr)) echo $nameErr; ?>
      </span></td>
    </tr>
	 <tr>
      <th scope="row">Date of Birth</th>
      <td><label>
      <input type="text"  value="<?php echo $row["dob"]; ?>" readonly="" />
      </label></td>
    </tr>
      <tr>
      <th scope="row">Address </th>
      <td><label>
      <input type="text" name="address" value="<?php echo $row["address"]; ?>" required />
      </label></td>
    </tr>
    <tr>
      <th scope="row">E-mail</th>
      <td><label><?php echo $row["email_id"]; ?></label></td>
	   <td width="240"><span style="color:#FF0000;">
  <?php if(isset($emailErr)) echo $emailErr; ?>
  </span></td>
    </tr>
	 <tr>
      <th scope="row">Phone Number </th>
      <td><label>
      <input type="text" name="contact" value="<?php echo $row["contact"]; ?>" required />
      </label></td>
	  <td width="279"> <span style="color:#FF0000;">
      <?php if(isset($phnErr)) echo $phnErr; ?>
      </span></td>
    </tr>
   
     <tr>
      <th scope="row">Created Date</th>
      <td><label>
      <input type="text"  value="<?php echo $row["created_at"]; ?>" readonly="" />
      </label></td>
    </tr>
  </table>
  <p>&nbsp;</p>
  <p>
    <label>
      <input type="submit" name="Submit" value="Update Profile" />
      </label>
  </p>
  <p>&nbsp;</p>
</form>
<p>&nbsp;</p>
</center>
	
	<!-- footer -->
	<div class="w3-agile-footer">
		<div class="container">
			
			<div class="agileits-w3layouts-copyright">
				<p>� 2018 Online eye care . All Rights Reserved | Design by <a href="https://www.facebook.com/sreekutty.prakash.9"> SSSP</a> </p>
			</div>
		</div>
	</div>
	<!-- //footer -->
</body>
</html>
