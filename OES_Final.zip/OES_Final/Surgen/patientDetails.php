<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<style type="text/css">
<!--
.style1 {font-weight: bold}
-->
</style>
</head>
<?php
session_start();
 include("header.php"); 
include 'dbconn.php';
//$id =$_SESSION["id"];
$pat_id= $_REQUEST['id'];
//$sapp_id= $_REQUEST['sapp_id'];
require_once("../ConnectionClass.php");
$obj= new ConnectionClass();
echo $sq2="select sapp_id from surgenappointment where pat_id='$pat_id'";
echo $c2=$obj->GetSingleData($sq2);
echo$sql="select * from patient where pat_id=$pat_id";// echo $sql;
		$result=@mysqli_query($con,$sql);
		$row=@mysqli_fetch_array($result);
// vie w medicine details
//$billno= rand(1,10000000);
//echo $pat_name = $row['pat_name'];
echo $sq3="select pat_name from patient where pat_id='$pat_id'";
echo $c3=$obj->GetSingleData($sq3);
echo $sq4="select address from patient where pat_id='$pat_id'";
echo $c4=$obj->GetSingleData($sq4);
echo $sq5="select gender from patient where pat_id='$pat_id'";
echo $c5=$obj->GetSingleData($sq5);
echo $sq6="select dob from patient where pat_id='$pat_id'";
echo $c6=$obj->GetSingleData($sq6);
//echo $sq3="select pat_name from patient where pat_id='$pat_id'";
//echo $c3=$obj->GetSingleData($sq3);
//echo $sq3="select pat_name from patient where pat_id='$pat_id'";
//echo $c3=$obj->GetSingleData($sq3);	
?>
<body>

<center>
  <p>&nbsp;</p>
  <div class="services-heading">
				<h2>Case Sheet</h2>
  </div>

<div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
	<ul id="myTab" class="nav nav-tabs" role="tablist">
		<li role="presentation" class="active"><a href="#home" id="home-tab" role="tab" data-toggle="tab" aria-controls="home" aria-expanded="true">Patient Details</a></li>
		<li role="presentation"><a href="#profile" role="tab" id="profile-tab" data-toggle="tab" aria-controls="profile">Prescriptions</a></li>
		<li role="presentation"><a href="#profile2" role="tab" id="profile2-tab" data-toggle="tab" aria-controls="profile2">Test Reports</a></li>
		<!--<li role="presentation"><a href="#profile3" role="tab" id="profile3-tab" data-toggle="tab" aria-controls="profile3">Add Bill</a></li>-->
		<li role="presentation"><a href="#profile3" role="tab" id="profile3-tab" data-toggle="tab" aria-controls="profile3">Doctor Prescriptions</a></li>
		<li role="presentation"><a href="#profile4" role="tab" id="profile4-tab" data-toggle="tab" aria-controls="profile4">Doctor Testdetails</a></li>

	</ul>
	
	<div id="myTabContent" class="tab-content">
		<div role="tabpanel" class="tab-pane fade in active" id="home" aria-labelledby="home-tab">
			<div class="well">
				<p>&nbsp;</p>
				<table width="791" height="196">
				<tr>
				  <th width="350" height="134" scope="row"><div align="center" class="style1">
					<p>Name</p>
					<p>&amp; </p>
					<p>Address </p>
				  </div></th>
				  <td width="429"><strong>
					<label>
					  : <?php echo $c3; ?>
					  ,<br />
				  </label>
					</strong>
					<p><strong> <?php echo $c4; ?> ,</strong></p>
					  <p><strong> <?php echo $row["email_id"]; ?> ,</strong></p>
					<p><strong> <?php echo $row["contact"]; ?> </strong></p></td></tr>
				
				<tr>
				  <th scope="row"><div align="center"><strong>Gender </strong></div></th>
				  <td><strong>
					<label>: 
					  <?php echo $c5; ?>          </label>
				  </strong></td>
				</tr>
				<tr>
				  <th scope="row"><div align="center"><strong>DOB </strong></div></th>
				  <td><strong>
					<label>: 
					  <?php echo $c6; ?>          </label>
				  </strong></td>
				</tr>
				</table>
		        <p>&nbsp;</p>
		  </div>
		</div>
		</div>
		<div role="tabpanel" class="tab-pane fade" id="profile" aria-labelledby="profile-tab">
				<p>&nbsp;</p>
				<table class="table">
				<thead>
				<tr>
				  <th height="46"><div align="center"><strong>Sl. No. </strong></div></th>
				  <th><div align="center"><strong>Surgen Name</strong></div></th>
				  <th><div align="center"><strong>Medicine Name</strong></div></th>
				  <th><div align="center"><strong>Dosage</strong></div></th>
				  <th><div align="center"><strong>No. of Days </strong></div></th>
				  <th><div align="center"><strong>Message</strong></div></th>
				</tr>
				</thead>
				<tbody>
				 <?php 
				 /*details of approved patients */
				$sql="select * from surgenprescription where pat_id=$pat_id"; //echo $sql;
				$result=mysqli_query($con,$sql);
				$s =0;
				while($row=@mysqli_fetch_array($result))
				{
						$s=$s+1;
						$s_id=$row['s_id']; 
						$sq="select * from surgen where s_id=$s_id"; //echo $sq;
						$re=@mysqli_query($con,$sq); 
						$r=@mysqli_fetch_array($re);
						$name= $r['name'];		//echo $name;	
			  ?>
				<tr>
				  <td><div align="center"><?php echo $s; ?>&nbsp;</div></td>
				  <td><div align="center"><?php echo $name; ?>&nbsp;</div></td>   
				  <td><div align="center"><?php echo $row['medicines']; ?>&nbsp;</div></td>
				  <td><div align="center"><?php echo $row['dosage']; ?>&nbsp;</div></td>
				  <td><div align="center"><?php echo $row['noofdays']; ?>&nbsp;</div></td>
				  <td><div align="center"><?php echo $row['msg']; ?>&nbsp;</div></td>
				</tr>
				<?php  } ?>
				</tbody>
			  </table>
			 
	            <p><a href="addPrescription.php?pat_id=<?php echo $pat_id; ?>&c2=<?php echo $c2; ?>">Add Prescription</a></p>
	            <p>&nbsp;</p>
	  </div>
		<div role="tabpanel" class="tab-pane fade" id="profile2" aria-labelledby="profile2-tab">
			 
			 <table class="table">
				<thead>
				<tr>
				  <th height="46"><div align="center"><strong>Sl. No. </strong></div></th>
				   <th><div align="center"><strong>Surgen Name</strong></div></th>
				  <th><div align="center"><strong>Date </strong></div></th>
				  <th><div align="center"><strong>Test</strong></div></th>
				  <th><div align="center"><strong>Report </strong></div></th>
				  <th><div align="center"><strong>Review</strong></div></th>
				</tr>
				</thead>
				<tbody>
				 <?php 
				 /*details of approved patients */
				$sql="select * from surgentest where pat_id=$pat_id"; //echo $sql;
				$result=mysqli_query($con,$sql);
				$s =0;
				while($row=@mysqli_fetch_array($result))
				{
						$s=$s+1;	
						$doc_id=$row['s_id']; 
						$sq="select * from surgen where s_id=$s_id"; //echo $sq;
						$re=@mysqli_query($con,$sq); 
						$r=@mysqli_fetch_array($re);
						$name= $r['name'];		//echo $name;			
			  ?>
				<tr>
				  <td><div align="center"><?php echo $s; ?>&nbsp;</div></td>
				   <td><div align="center"><?php echo $name; ?>&nbsp;</div></td>   
				  <td><div align="center"><?php echo $row['tdate']; ?>&nbsp;</div></td>
				  <td><div align="center"><?php echo $row['test']; ?>&nbsp;</div></td>
				  <td><div align="center"><?php echo $row['report']; ?>&nbsp;</div></td>
				  <td><div align="center"><?php echo $row['review']; ?>&nbsp;</div></td>
				</tr>
				<?php  } ?>
				</tbody>
				
		  </table>
  		 
		 <p><a href="addTestDetails.php?pat_id=<?php echo $pat_id; ?>&c2=<?php echo $c2; ?>">Add Test Details</a></p>
		 <p>&nbsp;</p>
		</div>
		<div role="tabpanel" class="tab-pane fade" id="profile3" aria-labelledby="profile3-tab">
				<p>&nbsp;</p>
				<table class="table">
				<thead>
				<tr>
				  <th height="46"><div align="center"><strong>Sl. No. </strong></div></th>
				  <th><div align="center"><strong>Doctor Name</strong></div></th>
				  <th><div align="center"><strong>Medicine Name</strong></div></th>
				  <th><div align="center"><strong>Dosage</strong></div></th>
				  <th><div align="center"><strong>No. of Days </strong></div></th>
				  <th><div align="center"><strong>Message</strong></div></th>
				</tr>
				</thead>
				<tbody>
				 <?php 
				 /*details of approved patients */
				$sql="select * from prescription where pat_id=$pat_id"; //echo $sql;
				$result=mysqli_query($con,$sql);
				$s =0;
				while($row=@mysqli_fetch_array($result))
				{
						$s=$s+1;
						$qry1="select doc_id from prescription where pat_id=$pat_id";
						 $c8=$obj->GetSingleData($qry1);
						//$doc_id=$row['doc_id']; 
						$sq="select * from doctor where doc_id=$c8"; //echo $sq;
					     $c9=$obj->GetSingleData($sq);
						$qry="select doctor_name from doctor where doctor_id=$c8";
						 $c7=$obj->GetSingleData($qry);
								//echo $name;	
			  ?>
				<tr>
				  <td><div align="center"><?php echo $s; ?>&nbsp;</div></td>
				  <td><div align="center"><?php echo $c7; ?>&nbsp;</div></td>   
				  <td><div align="center"><?php echo $row['medicines']; ?>&nbsp;</div></td>
				  <td><div align="center"><?php echo $row['dosage']; ?>&nbsp;</div></td>
				  <td><div align="center"><?php echo $row['noofDays']; ?>&nbsp;</div></td>
				  <td><div align="center"><?php echo $row['msg']; ?>&nbsp;</div></td>
				</tr>
				<?php  } ?>
				</tbody>
			  </table>
	  </div>
	  </div>
	  <div role="tabpanel" class="tab-pane fade" id="profile4" aria-labelledby="profile4-tab">
			 
			 <table class="table">
				<thead>
				<tr>
				  <th height="46"><div align="center"><strong>Sl. No. </strong></div></th>
				   <th><div align="center"><strong>Doctor Name</strong></div></th>
				  <th><div align="center"><strong>Date </strong></div></th>
				  <th><div align="center"><strong>Test</strong></div></th>
				  <th><div align="center"><strong>Report </strong></div></th>
				  <th><div align="center"><strong>Review</strong></div></th>
				</tr>
				</thead>
				<tbody>
				 <?php 
				 /*details of approved patients */
				$sql="select * from test where pat_id=$pat_id"; //echo $sql;
				$result=mysqli_query($con,$sql);
				$s =0;
				while($row=@mysqli_fetch_array($result))
				{
						$s=$s+1;	
						//echo $doc_id=$row['doc_id']; 
						$qr="select doc_id from test where pat_id='$pat_id'";
						 $di=$obj->GetSingleData($qr);
					 $q="select doctor_name from doctor where doctor_id='$di'";
					 $dn=$obj->GetSingleData($q);
						 $sq="select * from surgen where doc_id=$di"; //echo $sq;
						$re=@mysqli_query($con,$sq); 
						$r=@mysqli_fetch_array($re);
						//$name= $r['doctor_name'];		//echo $name;			
			  ?>
				<tr>
				  <td><div align="center"><?php echo $s; ?>&nbsp;</div></td>
				   <td><div align="center"><?php echo $dn; ?>&nbsp;</div></td>   
				  <td><div align="center"><?php echo $row['tDate']; ?>&nbsp;</div></td>
				  <td><div align="center"><?php echo $row['test']; ?>&nbsp;</div></td>
				  <td><div align="center"><?php echo $row['report']; ?>&nbsp;</div></td>
				  <td><div align="center"><?php echo $row['review']; ?>&nbsp;</div></td>
				</tr>
				<?php  } ?>
				</tbody>
				
		  </table>
		</div>
		
				  
		

</center>
	
	<!-- footer -->
	<div class="w3-agile-footer">
		<div class="container">
			
			<div class="agileits-w3layouts-copyright">
				<p>� 2018 Online eye care . All Rights Reserved | Design by <a href="https://www.facebook.com/sreekutty.prakash.9"> SSSP</a> </p>
			</div>
		</div>
	</div>
	<!-- //footer -->
</body>
</html>
