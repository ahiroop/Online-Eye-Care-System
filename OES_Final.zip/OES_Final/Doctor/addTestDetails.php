<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>
<?php 
session_start();
//$id =$_SESSION["id"];
$pat_id= $_REQUEST['pat_id'];
$app_id= $_REQUEST['app_id'];
include("header.php"); 
include 'dbconn.php';
require_once("../ConnectionClass.php");
$obj= new ConnectionClass();
$username=$_SESSION['username'];
echo $sql1="select doctor_id from doctor where email_id='$username'";
echo $c1=$obj->GetSingleData($sql1);

$sql="select * from patient where pat_id=$pat_id";// echo $sql;
		$result=mysqli_query($con,$sql);
		$row=mysqli_fetch_array($result);
		$pat_name = $row['pat_name'];

if($_SERVER["REQUEST_METHOD"] == "POST")	
{
	
	$test=$_POST['test'];
	$report=$_POST['report'];
	$review=$_POST['review'];
	$date= date('Y-m-d');
	
	$sql="insert into test(tDate,test,report,review,pat_id,doc_id) values ('$date','$test','$report','$review','$pat_id','$c1')";
		//echo $sql;
		mysqli_query($con,$sql) or die();
		
		echo '<script type="text/javascript"> alert("Added...!");</script>';
	$sql="update appointment set status='Visited' where app_id=$app_id";// echo $sql;
	mysqli_query($con,$sql) or die();
	header("location:bookingStatusToday.php");
	
	
}
	?>
<body>

<center>
<h1>&nbsp;</h1>
<h3 class="h3-w3l">Add Test Details </h3> 
<p><a href="patientDetails.php?id=<?php echo $pat_id; ?>&app_id=<?php echo $app_id; ?>"><i class=" fa  fa-arrow-left" aria-hidden="true"></i>Back</a></p>
<form  name="form1" method="post" >
  <table width="656" height="401">
    <tr>
      <th width="231" scope="row"> Name</th>
      <td width="153"><label>
        <input type="text" name="pat_name" value="<?php echo $pat_name; ?>" readonly="" />
      </label></td>
    </tr>
    <tr>
      <th scope="row">Test Name</th>
      <td><label>
      <input type="text" name="test"  required />
      </label></td>
    </tr>
   	<tr>
      <th scope="row">Report</th>
      <td><label>
      <input type="text" name="report"  required />
      </label></td>
    </tr>
	<tr>
      <th scope="row">Review</th>
      <td><label>
      <input type="text" name="review"  required />
      </label></td>
    </tr>
  
	
  </table>
  <p>
    <label>
    <input type="submit" name="Submit" value="Add Prescription" />
    </label>
  </p>
</form>
<p>&nbsp;</p>
</center>

</body>
</html>
