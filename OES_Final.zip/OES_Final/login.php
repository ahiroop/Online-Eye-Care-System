<?php
include("header.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
</head>
<body>

 <p>&nbsp;</p>
  <div class="services-heading">
				<h2>Login</h2>
  </div>

<p>&nbsp;</p>
<p>&nbsp;</p>

<center>
<form action="loginverify.php" method="POST">
  <table height="134" >
     
      <tr>
        <td width="276" height="67"><div align="center">Username</div></td>
        <td width="299"><label>
          <input type="text" name="username" required/>
        </label></td>
      </tr>
      <tr>
        <td height="59"><div align="center">Password</div></td>
        <td><label>
        <input type="password" name="password" required/>
        </label></td>
      </tr>
     
     
    </table>
	<p>
	  <input type="submit" name="ok" value="Login">
<a href="forgot_pass.php"> Forgot Password </a></p>
	<div>
	  <p>&nbsp;      </p>
	</div>
</div>
</form>
</center>
	<!-- footer -->
	<div class="w3-agile-footer">
		<div class="container">
			
			<div class="agileits-w3layouts-copyright">
				<p>� 2018 Online eye care . All Rights Reserved | Design by <a href="https://www.facebook.com/sreekutty.prakash.9"> SSSP</a> </p>
			</div>
		</div>
	</div>
	<!-- //footer -->
</body>
</html>
