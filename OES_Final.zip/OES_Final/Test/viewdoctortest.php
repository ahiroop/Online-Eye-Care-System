<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

</head>
<?php
session_start();
//session_start();
include("header.php"); 
include 'dbconn.php';
//require_once("../ConnectionClass.php");
//$obj= new ConnectionClass();
?>
<body>

<center>
 <p>&nbsp;</p>
  <div class="services-heading">
				<h2>View Test Details</h2>
  </div>

<p>&nbsp;</p>
<p>&nbsp;</p>

<form  name="form1" method="post" >

  <p>&nbsp;</p>
  <table width="744" height="78" class="table">
  <thead>
  <tr>
		<th>#</th>
		<th>Patient Name</th>
		<th>Doctor Name</th>
	    <th>Email</th>
		<th>Gender</th>
		<th>Contact No. </th>
		<th>Test</th>
	</tr>
 	</thead>
	<tbody>
	<?php
	    require_once("../ConnectionClass.php");	
        $obj=new ConnectionClass();
		    //echo $pat_id=$_REQUEST['pat_id'];
			$sql="SELECT * FROM patient p join test lg on p.pat_id=lg.pat_id JOIN doctor d ON lg.doc_id=d.doctor_id";
			$da=$obj->GetTable($sql);
			$s =0;
			foreach($da as $row)
			{
			$s=$s+1;
	?>
	
    <tr>
      <td><?php echo $s;?>&nbsp;</td>
      <td><?php echo $row['pat_name']; ?>&nbsp;</td>
	  <td><?php echo $row['doctor_name']; ?>&nbsp;</td>
	  <td><?php echo $row['email_id']; ?>&nbsp;</td>
	  <td><?php echo $row['gender']; ?>&nbsp;</td>
      <td><?php echo $row['contact']; ?>&nbsp;</td>
	  <td><?php echo $row['test']; ?>&nbsp;</td>
	  <td><div align="center"><a href="doctortestreport.php?pat_id=<?php echo $row['pat_id'];?>doc_name=<?php echo $row['doctor_name'];?>">Generate Report</a>&nbsp;</div></td>
	  <td><div align="center"><a href="pat_details.php?pat_id=<?php echo $row['pat_id']; ?>">Surgen Test</a>&nbsp;</div></td>
    </tr>
	
	<?php  } ?>
	</tbody>
  </table>
  <p>&nbsp;</p>
</form>
<p>&nbsp;</p>
</center>
	<!-- footer -->
	<div class="w3-agile-footer">
		<div class="container">
			
			<div class="agileits-w3layouts-copyright">
				<p>� 2018 Online eye care . All Rights Reserved | Design by <a href="https://www.facebook.com/sreekutty.prakash.9"> SSSP</a> </p>
			</div>
		</div>
	</div>
	<!-- //footer -->
</body>
</html>
