<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

</head>
<?php
session_start();

include("header.php"); 
include 'dbconn.php';
require_once("../ConnectionClass.php");
$obj= new ConnectionClass();
$username=$_SESSION['username'];
echo $sql1="select pat_id from patient where email_id='$username'";
echo $c1=$obj->GetSingleData($sql1);
//$id =$_SESSION["id"];

?>
<body>

<center>
 <p>&nbsp;</p>
  <div class="services-heading">
				<h2>View Prescription</h2>
  </div>

<p>&nbsp;</p>
<p>&nbsp;</p>


<form  name="form1" method="post" >

  
  	<table class="table">
	<thead>
    <tr>
      <th height="46"><div align="center"><strong>Sl. No. </strong></div></th>
	  <th><div align="center"><strong>Doctor Name</strong></div></th>
      <th><div align="center"><strong>Medicine Name</strong></div></th>
      <th><div align="center"><strong>Dosage</strong></div></th>
      <th><div align="center"><strong>No. of Days </strong></div></th>
      <th><div align="center"><strong>Message</strong></div></th>
    </tr>
	</thead>
	<tbody>
	 <?php 
	 /*details of approved patients */
  	$sql="select * from surgenprescription where pat_id=$c1"; //echo $sql;
	$result=mysqli_query($con,$sql);
	$s =0;
 	while($row=@mysqli_fetch_array($result))
	{
			$s=$s+1;
			$s_id=$row['s_id']; 
			$sq="select * from surgen where s_id=$s_id"; //echo $sq;
			$re=@mysqli_query($con,$sq); 
			$r=@mysqli_fetch_array($re);
			$name= $r['name'];		//echo $name;	
  ?>
    <tr>
      <td><div align="center"><?php echo $s; ?>&nbsp;</div></td>
      <td><div align="center"><?php echo $name; ?>&nbsp;</div></td>   
	  <td><div align="center"><?php echo $row['medicines']; ?>&nbsp;</div></td>
      <td><div align="center"><?php echo $row['dosage']; ?>&nbsp;</div></td>
      <td><div align="center"><?php echo $row['noofdays']; ?>&nbsp;</div></td>
	  <td><div align="center"><?php echo $row['msg']; ?>&nbsp;</div></td>
    </tr>
	<?php  } ?>
	</tbody>
  </table>
 
  <p>&nbsp;</p>
</form>
<p>&nbsp;</p>
</center>
	
	<!-- footer -->
	<div class="w3-agile-footer">
		<div class="container">
			
			<div class="agileits-w3layouts-copyright">
				<p>� 2018 Online eye care . All Rights Reserved | Design by <a href="https://www.facebook.com/sreekutty.prakash.9"> SSSP</a> </p>
			</div>
		</div>
	</div>
	<!-- //footer -->
</body>
</html>
