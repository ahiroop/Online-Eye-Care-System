<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

</head>
<?php
include("header.php"); 
require_once("ConnectionClass.php");
$obj=new ConnectionClass();
if($_SERVER["REQUEST_METHOD"] == "POST")	
{
	
	$pat_name=$_POST['name'];
	if(!preg_match("/^[a-zA-Z ]*$/",$pat_name))
		{
			$nameErr="Name contain lettters and white space";
			$status="true";
		}
	$email_id=$_POST['email'];
	if(!preg_match("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$^",$email_id))
		{
			$emailErr="Invaild Email Id";
			$status="true";
		}
	$dob=$_POST['dob'];
	$created_at= date('Y-m-d');
	//dob Validation
	if($dob > $created_at)
		{
			$dobErr="Invalid Date of Birth";
			$status="true";
		}
	$gender=$_POST['gender'];
	$address=$_POST['address'];
	$contact=$_POST['phone'];
	if(!preg_match("/^[0-9]{10}$/",$contact))
		{
			$contactNoErr="Invaild Mobile Number";
			$status="true";
		}
	
	
	//$loginId=$_POST['loginId'];
	$password=($_POST['password']);
	$cpassword=($_POST['cpassword']);
	echo $email_id=$_POST['email'];
	
	if($password != $cpassword)
		{
		$cpasswordErr="Passwords does not match";
		$status="true";
		}
	if(!isset($status))
	{
	
		echo $sql="select * from patient where pat_name='$pat_name' and contact='$contact'";
			$result=@mysqli_query($con,$sql);
			$record=@mysqli_num_rows($result);
			if($record == 1)
			{
				$err ='true';
				echo '<script type="text/javascript"> alert("Duplicate User Deatails");window.Location=\'login.php\';</script>';
			}
		
		echo $sql="select * from login where username='$email_id'";
			$result=@mysqli_query($con,$sql);
			$record=@mysqli_num_rows($result);
			if($record == 1)
			{
				$err ='true';
				echo '<script type="text/javascript"> alert("User name not available try another one.. !");window.Location=\'login.php\';</script>';
			}
		echo	$qry="select count(username) from login where username ='$email_id'";
          echo  $counter=$obj->GetSingleData($qry);
		  if($counter== 1)
			{
				$err ='true';
				echo '<script type="text/javascript"> alert("username already exist");window.Location=\'patientReg.php\';</script>';
			}
	 	
		if(!isset($err)) 
		 { 
		 	
		 
		  	echo $sql="insert into patient(pat_name,email_id,dob,gender,address,contact,created_at) values ('$pat_name','$email_id','$dob','$gender','$address','$contact','$created_at')";
			//echo $sql;
			@mysqli_query($con,$sql) or die();
			$sql="select max(pat_id) from patient";
			$result=@mysqli_query($con,$sql);
			$row=@mysqli_fetch_array($result);
			$id=$row[0];
				echo $sql="insert into login(username,password,utype,status) values ('$email_id','$password','patient','active')";
			//echo $sql;
			@mysqli_query($con,$sql) or die();
			echo '<script type="text/javascript"> alert("Successfully Registered");window.Location=\'login.php\';</script>';
		}
	}
	
}
	?>
<body>

<center>

  <p>&nbsp;</p>
  <div class="services-heading">
				<h2>Patient Registration</h2>
  </div>

<p>&nbsp;</p>
<p>&nbsp;</p>
<form  name="form1" method="post" >
  <table width="428" height="401">
    <tr>
      <th width="142" scope="row">Name</th>
      <td width="186"><label>
        <input type="text" name="name" value="<?php if(isset($pat_name)) echo $pat_name; ?>" required />
      </label></td>
	  <td width="84"> <span style="color:#FF0000;"><?php if(isset($nameErr)) echo $nameErr; ?></span></td>
    </tr>
   
    <tr>
      <th scope="row">Gender</th>
      <td><label>
      <input name="gender" type="radio" value="Male" checked="checked" /> 
      Male 
      </label>
        <label>
        <input name="gender" type="radio" value="Female" />
 Female        </label></td>
    </tr>
    <tr>
      <th scope="row">Date of Birth </th>
      <td><label>
      <input type="date" name="dob" value="<?php if(isset($dob)) echo $dob; ?>" required/>
     </label></td>
	 <td> <span style="color:#FF0000;">
      <?php if(isset($dobErr)) echo $dobErr; ?>
      </span></td>
    </tr>
	<tr>
      <th scope="row">Address </th>
      <td><label>
      <input type="text" name="address" value="<?php if(isset($address)) echo $address; ?>" required />
      </label></td>
    </tr>
    <tr>
      <th scope="row">Contact Number </th>
      <td><label>
      <input type="text" name="phone" value="<?php if(isset($contact)) echo $contact; ?>" required />
	 	</label>
       </td>
	   <td> <span style="color:#FF0000;">
        <?php if(isset($contactNoErr)) echo $contactNoErr; ?>
        </span></td>
    </tr>
    <tr>
      <th scope="row">Email Id </th>
      <td><label>
      <input type="email" name="email" value="<?php if(isset($email_id)) echo $email_id; ?>" required />
      </label></td>
	    <td> <span style="color:#FF0000;">
        <?php if(isset($emailErr)) echo $emailErr; ?>
        </span></td>
    </tr>
   
	<tr>
      <th scope="row">Password</th>
      <td><label>
      <input type="password" name="password" required />
      </label></td>
    </tr>
    <tr>
      <th scope="row">Confirm Password</th>
      <td><label>
      <input type="password" name="cpassword" required />
     </label></td>
	 <td> <span style="color:#FF0000;">
      <?php if(isset($cpasswordErr)) echo $cpasswordErr; ?>
      </span></td>
    </tr>
	
  </table>
  <p>
    <label>
    <input type="submit" name="Submit" value="Register" />
    </label>
  </p>
</form>
<p>&nbsp;</p>
</center>
	<!-- footer -->
	<div class="w3-agile-footer">
		<div class="container">
			
			<div class="agileits-w3layouts-copyright">
				<p>� 2018 Online eye care . All Rights Reserved | Design by <a href="https://www.facebook.com/sreekutty.prakash.9"> SSSP</a> </p>
			</div>
		</div>
	</div>
	<!-- //footer -->
</body>
</html>
