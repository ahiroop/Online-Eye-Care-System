<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

</head>
<?php
session_start();
include("header.php"); 
include 'dbconn.php';
//$id =$_SESSION["id"];
require_once("../ConnectionClass.php");
$obj= new ConnectionClass();
$username=$_SESSION['username'];
echo $sql1="select doctor_id from doctor where email_id='$username'";
echo $c1=$obj->GetSingleData($sql1);
$sql="select * from doctor where doctor_id=$c1";// echo $sql;
		$result=@mysqli_query($con,$sql);
		$row=@mysqli_fetch_array($result);

	?>
<body>

<center>
<h1>&nbsp;</h1>
 <p>&nbsp;</p>
  <div class="services-heading">
				<h2>View Profile</h2>
  </div>

<p>&nbsp;</p>
<p>&nbsp;</p>
<div class="well">
<form  name="form1" method="post" >
  <table width="556" height="214">
    <tr>
      <th width="271" scope="row"><div align="left">Doctor Name</div></th>
      <td width="273"><label>
        : <?php echo $row["doctor_name"]; ?>
      </label></td>
    </tr>
   
    <tr>
      <th scope="row"><div align="left">Email Id </div></th>
      <td><label>: <?php echo $row["email_id"]; ?>
      </label></td>
    </tr>
	 <tr>
      <th scope="row"><div align="left">Contact Number </div></th>
      <td><label>: 
      <?php echo $row["phone"]; ?>
      </label></td>
    </tr>
  </table>
 
</form>
</div>
<p>&nbsp;</p>
</center>
	
	<!-- footer -->
	<div class="w3-agile-footer">
		<div class="container">
			
			<div class="agileits-w3layouts-copyright">
				<p>� 2018 Online eye care . All Rights Reserved | Design by <a href="https://www.facebook.com/sreekutty.prakash.9"> SSSP</a> </p>
			</div>
		</div>
	</div>
	<!-- //footer -->
</body>
</html>
