<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

</head>
<?php
session_start();
require_once("../ConnectionClass.php");
$obj=new ConnectionClass();
include("header.php"); 
include 'dbconn.php';
$username=$_SESSION['username'];
echo $sql1="select pat_id from patient where email_id='$username'";
echo $c1=$obj->GetSingleData($sql1);

?>
<body>

<center>
 <p>&nbsp;</p>
  <div class="services-heading">
				<h2>My Orders</h2>
  </div>

<p>&nbsp;</p>
<p>&nbsp;</p>


<form  name="form1" method="post" >

  	<table class="table">
	<thead>
    <tr>
      <th height="48"><strong>Sl. No. </strong></th>
      <th><strong>Product Name</strong></th>
      <th><strong>Model</strong></th>
      <th><strong>Quantity</strong></th>
	  <th><strong>Cost per item</strong></th>
	  <th><strong>net Amount</strong></th>
    </tr>
	</thead>
	<tbody>
	<?php
			$sql="select * from orderpdt where pat_id='$c1'"; //echo $sql;
			$result=@mysqli_query($con,$sql);
			$s =0;
			while($row=@mysqli_fetch_array($result))
			{
			$s=$s+1;
			$pdt_id =  $row['pdt_id'];
			$qty =  $row['qty'];
				$ss="select * from product where pdt_id =$pdt_id";//echo $ss;
				$re=@mysqli_query($con,$ss);
				$r=@mysqli_fetch_array($re);
				$pdt_name = $r['pdt_name'];
				$pdt_model = $r['pdt_model'];
				$pdt_cost = $r['pdt_cost'];
				$cost = $qty * $pdt_cost;
	?>
    <tr>
      <td><?php echo $s; ?>&nbsp;</td>
	  <td><?php echo $pdt_name; ?>&nbsp;</td>
	  <td><?php echo $pdt_model; ?>&nbsp;</td>
	  <td><?php echo $qty; ?>&nbsp;</td>
	  <td><?php echo $pdt_cost; ?>&nbsp;</td>
	  <td><?php echo $cost; ?>&nbsp;</td>
      
	
	<?php  } ?>
	</tbody>
  </table>
  <p>&nbsp;</p>
</form>
<p>&nbsp;</p>
</center>
	
	<!-- footer -->
	<div class="w3-agile-footer">
		<div class="container">
			
			<div class="agileits-w3layouts-copyright">
				<p>� 2018 Online eye care . All Rights Reserved | Design by <a href="https://www.facebook.com/sreekutty.prakash.9"> SSSP</a> </p>
			</div>
		</div>
	</div>
	<!-- //footer -->
</body>
</html>
