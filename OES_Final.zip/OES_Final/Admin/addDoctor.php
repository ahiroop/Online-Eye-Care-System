<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

</head>
<?php  
session_start();
require_once("../ConnectionClass.php");
$obj=new ConnectionClass();
include("header.php");
include('dbconn.php');


if($_SERVER["REQUEST_METHOD"] == "POST")	
{
	
	$doctor_name=$_POST['doctor_name'];
	if(!preg_match("/^[a-zA-Z ]*$/",$doctor_name))
		{
			$nameErr="Name contain lettters and white space";
			$status="true";
		}
	$cat=$_POST['category'];
	if(!preg_match("/^[a-zA-Z ]*$/",$cat))
		{
			$cnameErr="Name contain lettters and white space";
			$status="true";
		}
	$email_id=$_POST['email_id'];
	if(!preg_match("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$^",$email_id))
		{
			$emailErr="Invaild Email Id";
			$status="true";
		}
	$phone=$_POST['phone'];
	if(!preg_match("/^[0-9]{10}$/",$phone))
		{
			$phnErr="Phoe number contain 10 digits";
			$status="true";
		}
	
	echo $email_id=$_POST['email_id'];
	echo $password=$_POST['password'];
	echo $cpassword=$_POST['cpassword'];
	
	
	if($password != $cpassword)
		{
		$cpasswordErr="Passwords does not match";
		$status="true";
		}
	if(!isset($status))
	{
		echo $sql="select * from doctor where doctor_name='$doctor_name' and phone='$phone'";
			$result=mysqli_query($con,$sql);
			$record=mysqli_num_rows($result);
			if($record == 1)
			{
				$err ='true';
				//echo '<script type="text/javascript"> alert("Duplicate Doctor Deatails");</script>';
			}
	echo $sql="select * from login where username='$email_id'";
			$result=mysqli_query($con,$sql);
			$record=mysqli_num_rows($result);
			if($record == 1)
			{
				$err ='true';
				//echo '<script type="text/javascript"> alert("User name not available try another one.. !");window.Location=\'login.php\';</script>';
			}
			echo	$qry="select count(username) from login where username ='$email_id'";
          echo  $counter=$obj->GetSingleData($qry);
		  if($counter== 1)
			{
				$err ='true';
				echo '<script type="text/javascript"> alert("username already exist");window.Location=\'addDoctor.php\';</script>';
			}
	 	
		
	if(!isset($err)) 
		 { 		
		
			echo $sql="insert into doctor(doctor_name,category,email_id,phone) values ('$doctor_name','$cat','$email_id','$phone')";
			//echo $sql;
			mysqli_query($con,$sql) or die();
		echo $sql="select max(doctor_id) from doctor";
			$result=mysqli_query($con,$sql);
			$row=mysqli_fetch_array($result);
			echo $id=$row[0];
			echo 	$sql="insert into login(username,password,utype,status) values ('$email_id','$password','doctor','active')";
			//echo $sql;
			mysqli_query($con,$sql) or die();
			//echo '<script type="text/javascript"> alert("Successfully Registered New Doctor");</script>';
		}
	}
	
}

	?>


<center>
 <p>&nbsp;</p>
  <div class="services-heading">
				<h2> Add New Doctor</h2>
  </div>

<p>&nbsp;</p>
<p>&nbsp;</p>
<form  name="form1" method="post" >
  <table width="656" height="401">
    <tr>
      <th width="231" scope="row">Doctor Name</th>
      <td width="153"><label>
        <input type="text" name="doctor_name" value="<?php if(isset($doctor_name)) echo $doctor_name; ?>" required />
      </label></td>
	   <td> <span style="color:#FF0000;">
      <?php if(isset($nameErr)) echo $nameErr; ?>
      </span></td>
	
    </tr>
	<tr>
	<th width="231" scope="row">Category</th>
      <td width="153"><label>
   <select name="category" value="<?php if(isset($cat)) echo $cat; ?>">
		<option>---Select Type--</option>
		 <option value="Ophthalmologist">Ophthalmologist</option>
		 <option value="Low Vision Specialist">Low Vision Specialist</option>
		 <option value="Surgen">Surgen</option>
		 <option value="General">General</option>
		 </label></td>
		 
		 
 
 </select>
 </tr>
    <tr>
      <th scope="row">Email Id </th>
      <td><label>
      <input type="email" name="email_id" value="<?php if(isset($email_id)) echo $email_id; ?>" required />
      </label></td>
	   <td width="240"><span style="color:#FF0000;">
  <?php if(isset($emailErr)) echo $emailErr; ?>
  </span></td>
    </tr>
	 <tr>
      <th scope="row"> Phone Number </th>
      <td><label>
      <input type="text" name="phone" value="<?php if(isset($phone)) echo $phone; ?>" required />
      </label></td>
	   <td> <span style="color:#FF0000;">
      <?php if(isset($phnErr)) echo $phnErr; ?>
      </span></td>
    </tr>
  
	<tr>
      <th scope="row">Password</th>
      <td><label>
      <input type="password" name="password" required />
      </label></td>
    </tr>
    <tr>
      <th scope="row">Confirm Password</th>
      <td><label>
      <input type="password" name="cpassword" required />
     </label></td>
	 <td> <span style="color:#FF0000;">
      <?php if(isset($cpasswordErr)) echo $cpasswordErr; ?>
      </span></td>
    </tr>
	
  </table>
  <p>
    <label>
    <input type="submit" name="Submit" value="Register New Doctor" />
    </label>
  </p>
</form>
<p>&nbsp;</p>
</center>
	<!-- footer -->
	<div class="w3-agile-footer">
		<div class="container">
			
			<div class="agileits-w3layouts-copyright">
				<p>� 2018 Online eye care . All Rights Reserved | Design by <a href="https://www.facebook.com/sreekutty.prakash.9"> SSSP</a> </p>
			</div>
		</div>
	</div>
	<!-- //footer -->
</body>
</html>
